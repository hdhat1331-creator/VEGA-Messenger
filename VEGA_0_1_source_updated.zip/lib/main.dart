import 'package:flutter/material.dart';

void main() => runApp(const VegaApp());

const navy = Color(0xFF0B1020);
const panel = Color(0xFF171F3A);
const purple = Color(0xFF7655D9);
const lavender = Color(0xFFB69CFF);

class VegaApp extends StatefulWidget {
  const VegaApp({super.key});
  @override
  State<VegaApp> createState() => _VegaAppState();
}

class _VegaAppState extends State<VegaApp> {
  bool english = false;
  String tr(String fa, String en) => english ? en : fa;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'VEGA',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: navy,
        colorScheme: const ColorScheme.dark(
          primary: purple, secondary: lavender, surface: panel,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true, fillColor: panel,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15),
            borderSide: BorderSide.none,
          ),
        ),
        useMaterial3: true,
      ),
      home: Directionality(
        textDirection: english ? TextDirection.ltr : TextDirection.rtl,
        child: WelcomePage(
          english: english,
          onLanguage: () => setState(() => english = !english),
          tr: tr,
        ),
      ),
    );
  }
}

class WelcomePage extends StatelessWidget {
  final bool english;
  final VoidCallback onLanguage;
  final String Function(String, String) tr;
  const WelcomePage({super.key, required this.english, required this.onLanguage, required this.tr});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              Align(
                alignment: AlignmentDirectional.topEnd,
                child: TextButton.icon(
                  onPressed: onLanguage,
                  icon: const Icon(Icons.language),
                  label: Text(english ? 'فارسی' : 'English'),
                ),
              ),
              const Spacer(),
              Container(
                width: 104, height: 104,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(32),
                  gradient: const LinearGradient(colors: [purple, Color(0xFF34245F)]),
                  boxShadow: [BoxShadow(color: purple.withOpacity(.28), blurRadius: 30)],
                ),
                child: const Icon(Icons.forum_rounded, size: 54, color: Colors.white),
              ),
              const SizedBox(height: 22),
              const Text('VEGA', style: TextStyle(fontSize: 42, fontWeight: FontWeight.w900, letterSpacing: 5, color: lavender)),
              const SizedBox(height: 8),
              Text(tr('ارتباطی فراتر از انتظار', 'CONNECT BEYOND'), style: const TextStyle(color: Colors.white70, letterSpacing: 2)),
              const Spacer(),
              SizedBox(width: double.infinity, height: 54,
                child: FilledButton(
                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AuthPage(tr: tr))),
                  child: Text(tr('ورود به VEGA', 'SIGN IN')),
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(width: double.infinity, height: 54,
                child: OutlinedButton(
                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AuthPage(tr: tr, register: true))),
                  child: Text(tr('ساخت حساب کاربری', 'CREATE ACCOUNT')),
                ),
              ),
              const SizedBox(height: 28),
              Text(tr('نسخه آزمایشی ۰.۱ • فقط پیش‌نمایش رابط کاربری', 'BETA 0.1 • UI PREVIEW ONLY'), style: const TextStyle(color: Colors.white38, fontSize: 11)),
            ],
          ),
        ),
      ),
    );
  }
}

class AuthPage extends StatefulWidget {
  final String Function(String, String) tr;
  final bool register;
  const AuthPage({super.key, required this.tr, this.register = false});
  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  bool register = false;
  bool obscure = true;
  @override
  void initState() { super.initState(); register = widget.register; }

  @override
  Widget build(BuildContext context) {
    final tr = widget.tr;
    return Scaffold(
      appBar: AppBar(backgroundColor: navy),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(24),
          children: [
            const Center(child: Text('VEGA', style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900, color: lavender, letterSpacing: 4))),
            const SizedBox(height: 28),
            Text(register ? tr('ساخت حساب جدید', 'Create account') : tr('خوش برگشتی', 'Welcome back'), style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text(tr('با نام کاربری خود وارد دنیای VEGA شو.', 'Sign in to VEGA with your username.'), style: const TextStyle(color: Colors.white60)),
            const SizedBox(height: 26),
            if (register) ...[
              TextField(decoration: InputDecoration(labelText: tr('نام نمایشی', 'Display name'), prefixIcon: const Icon(Icons.badge_outlined))),
              const SizedBox(height: 14),
            ],
            TextField(decoration: InputDecoration(labelText: tr('نام کاربری', 'Username'), prefixIcon: const Icon(Icons.person_outline))),
            const SizedBox(height: 14),
            TextField(
              obscureText: obscure,
              decoration: InputDecoration(
                labelText: tr('رمز عبور', 'Password'),
                prefixIcon: const Icon(Icons.lock_outline),
                suffixIcon: IconButton(icon: Icon(obscure ? Icons.visibility : Icons.visibility_off), onPressed: () => setState(() => obscure = !obscure)),
              ),
            ),
            if (register) ...[
              const SizedBox(height: 14),
              TextField(obscureText: true, decoration: InputDecoration(labelText: tr('تکرار رمز عبور', 'Confirm password'), prefixIcon: const Icon(Icons.lock_reset))),
            ],
            const SizedBox(height: 24),
            SizedBox(height: 52, child: FilledButton(
              onPressed: () => Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => HomePage(tr: tr)), (_) => false),
              child: Text(register ? tr('ایجاد حساب', 'Create account') : tr('ورود', 'Sign in')),
            )),
            TextButton(
              onPressed: () => setState(() => register = !register),
              child: Text(register ? tr('حساب داری؟ ورود', 'Already registered? Sign in') : tr('حساب نداری؟ ثبت‌نام کن', 'New here? Create account')),
            ),
            const SizedBox(height: 12),
            Text(tr('این نسخه صرفاً نمایشی است؛ هنوز حساب واقعی ساخته یا بررسی نمی‌شود.', 'Demo only: credentials are not saved or verified yet.'), textAlign: TextAlign.center, style: const TextStyle(color: Colors.orangeAccent, fontSize: 12)),
          ],
        ),
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  final String Function(String, String) tr;
  const HomePage({super.key, required this.tr});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  @override
  Widget build(BuildContext context) {
    final tr = widget.tr;
    final titles = [tr('گفتگوها', 'Chats'), tr('مخاطبین', 'Contacts'), tr('پروفایل', 'Profile')];
    return Scaffold(
      appBar: AppBar(
        title: Text(titles[tab], style: const TextStyle(fontWeight: FontWeight.bold)),
        actions: [IconButton(onPressed: () {}, icon: const Icon(Icons.search)), const SizedBox(width: 6)],
      ),
      body: IndexedStack(index: tab, children: [
        ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), gradient: const LinearGradient(colors: [Color(0xFF33245F), Color(0xFF172443)])),
              child: Row(children: [
                const Icon(Icons.auto_awesome, color: lavender, size: 30),
                const SizedBox(width: 12),
                Expanded(child: Text(tr('به VEGA خوش آمدی! این پیش‌نمایش صفحه گفتگوهاست.', 'Welcome to VEGA! This is a chat-list preview.'), style: const TextStyle(fontWeight: FontWeight.w600))),
              ]),
            ),
            const SizedBox(height: 18),
            for (final item in [
              ['A', 'آرمان', 'سلام! به VEGA خوش اومدی 👋', '۱۲:۴۰'],
              ['S', 'Sara', 'See you soon!', '۱۱:۲۵'],
              ['M', 'محمد', 'فایل رو دریافت کردم.', 'دیروز'],
              ['N', 'Nika', 'مرسی 🌙', 'دوشنبه'],
            ])
              ListTile(
                contentPadding: const EdgeInsets.symmetric(vertical: 5, horizontal: 4),
                leading: CircleAvatar(radius: 25, backgroundColor: purple, child: Text(item[0], style: const TextStyle(fontWeight: FontWeight.bold))),
                title: Text(item[1], style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text(item[2], maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white60)),
                trailing: Text(item[3], style: const TextStyle(color: Colors.white38, fontSize: 11)),
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChatPage(name: item[1], tr: tr))),
              ),
          ],
        ),
        Center(child: Column(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.people_alt_outlined, size: 55, color: lavender), const SizedBox(height: 12), Text(tr('مخاطبین در نسخه‌های بعدی', 'Contacts coming soon'))])),
        Center(child: Column(mainAxisSize: MainAxisSize.min, children: [const CircleAvatar(radius: 38, backgroundColor: purple, child: Icon(Icons.person, size: 42)), const SizedBox(height: 12), const Text('VEGA USER', style: TextStyle(fontWeight: FontWeight.bold)), Text(tr('پروفایل آزمایشی', 'Demo profile'), style: const TextStyle(color: Colors.white60))])),
      ]),
      floatingActionButton: tab == 0 ? FloatingActionButton(backgroundColor: purple, onPressed: () => setState(() => tab = 1), child: const Icon(Icons.edit)) : null,
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: [
          NavigationDestination(icon: const Icon(Icons.chat_bubble_outline), label: tr('گفتگوها', 'Chats')),
          NavigationDestination(icon: const Icon(Icons.people_outline), label: tr('مخاطبین', 'Contacts')),
          NavigationDestination(icon: const Icon(Icons.person_outline), label: tr('پروفایل', 'Profile')),
        ],
      ),
    );
  }
}

class ChatPage extends StatefulWidget {
  final String name;
  final String Function(String, String) tr;
  const ChatPage({super.key, required this.name, required this.tr});
  @override
  State<ChatPage> createState() => _ChatPageState();
}
class _ChatPageState extends State<ChatPage> {
  final controller = TextEditingController();
  final messages = <String>['سلام! به VEGA خوش اومدی 👋', 'این یک گفت‌وگوی نمایشی است.'];
  @override
  void dispose() { controller.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    final tr = widget.tr;
    return Scaffold(
      appBar: AppBar(title: Row(children: [const CircleAvatar(backgroundColor: purple, child: Icon(Icons.person)), const SizedBox(width: 10), Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(widget.name, style: const TextStyle(fontSize: 16)), Text(tr('آخرین بازدید اخیراً', 'last seen recently'), style: const TextStyle(fontSize: 11, color: Colors.white54))])])),
      body: Column(children: [
        Expanded(child: ListView.builder(padding: const EdgeInsets.all(16), itemCount: messages.length, itemBuilder: (_, i) => Align(
          alignment: i.isEven ? AlignmentDirectional.centerStart : AlignmentDirectional.centerEnd,
          child: Container(margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 11), constraints: const BoxConstraints(maxWidth: 290), decoration: BoxDecoration(color: i.isEven ? panel : const Color(0xFF49358A), borderRadius: BorderRadius.circular(17)), child: Text(messages[i])),
        ))),
        SafeArea(top: false, child: Padding(padding: const EdgeInsets.all(10), child: Row(children: [
          Expanded(child: TextField(controller: controller, decoration: InputDecoration(hintText: tr('پیام بنویس...', 'Write a message...'), contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12)))),
          const SizedBox(width: 8),
          IconButton.filled(onPressed: () { if (controller.text.trim().isEmpty) return; setState(() { messages.add(controller.text.trim()); controller.clear(); }); }, icon: const Icon(Icons.send), style: IconButton.styleFrom(backgroundColor: purple)),
        ]))),
      ]),
    );
  }
}
