# VEGA Messenger — Version 0.2

This ZIP contains a Flutter source project scaffold for the VEGA 0.2 UI prototype.

## Included
- Welcome / demo sign-in and registration screens
- Main navigation: Chats, Groups, Channels, Settings
- Demo chat screen with local in-memory message bubbles
- Profile and search screens
- Persian-first dark navy / turquoise / purple UI
- The two exact original logo images supplied by the user:
  - `assets/images/vega_logo_original.jpg` — in-app branding
  - `assets/images/vega_app_icon_original.jpg` — source image for launcher icon

## Important limitations
This is a UI prototype, not a production messenger. Sign-in is not connected to a server,
accounts are not persisted, chat messages are local/in-memory only, and groups, channels,
search, calls, Gold, file transfer, and notifications are not backed by services yet.
No privacy/security promises should be made until the backend is implemented and tested.

## Build
Run:
```bash
flutter pub get
flutter create . --platforms=android
flutter build apk --release
```

The generated APK will be at `build/app/outputs/flutter-apk/app-release.apk`.

The uploaded logo images are included unchanged. The app icon source is included unchanged;
launcher-icon integration is a separate Android packaging step.
