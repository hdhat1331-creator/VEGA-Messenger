import 'package:flutter/material.dart';

void main() => runApp(const VegaApp());

const navy = Color(0xFF0B1220);
const panel = Color(0xFF121D30);
const panel2 = Color(0xFF19263D);
const cyan = Color(0xFF22DCCB);
const purple = Color(0xFFB43CE8);
const muted = Color(0xFF93A4BA);

class VegaApp extends StatelessWidget {
  const VegaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'VEGA Messenger',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: navy,
        colorScheme: ColorScheme.fromSeed(
          seedColor: purple,
          brightness: Brightness.dark,
          surface: panel,
        ),
        fontFamily: null,
        useMaterial3: true,
      ),
      home: const WelcomePage(),
    );
  }
}

class BrandLogo extends StatelessWidget {
  final double width;
  const BrandLogo({super.key, this.width = 210});

  @override
  Widget build(BuildContext context) => ClipRRect(
    borderRadius: BorderRadius.circular(18),
    child: Image.asset(
      'assets/images/vega_logo_original.jpg',
      width: width,
      fit: BoxFit.contain,
    ),
  );
}

class WelcomePage extends StatefulWidget {
  const WelcomePage({super.key});
  @override
  State<WelcomePage> createState() => _WelcomePageState();
}

class _WelcomePageState extends State<WelcomePage> {
  bool register = false;
  final name = TextEditingController();
  final id = TextEditingController();
  final password = TextEditingController();

  @override
  void dispose() {
    name.dispose(); id.dispose(); password.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 440),
              child: Column(
                children: [
                  const SizedBox(height: 20),
                  const BrandLogo(width: 250),
                  const SizedBox(height: 28),
                  Text(register ? 'ساخت حساب VEGA' : 'خوش آمدی',
                    style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  const Text('ارتباطی ساده، سریع و نزدیک‌تر',
                    style: TextStyle(color: muted)),
                  const SizedBox(height: 26),
                  if (register) _field(name, 'نام و نام خانوادگی', Icons.person),
                  _field(id, 'شناسه کاربری (مثلاً VEGA_12345)', Icons.alternate_email),
                  _field(password, 'رمز عبور', Icons.lock, obscure: true),
                  const SizedBox(height: 18),
                  SizedBox(width: double.infinity, height: 52,
                    child: FilledButton(
                      style: FilledButton.styleFrom(
                        backgroundColor: purple,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
                      onPressed: () {
                        if (id.text.trim().isEmpty || password.text.isEmpty ||
                            (register && name.text.trim().isEmpty)) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('لطفاً فیلدهای لازم را تکمیل کن.')));
                          return;
                        }
                        Navigator.pushReplacement(context,
                          MaterialPageRoute(builder: (_) => const MainPage()));
                      },
                      child: Text(register ? 'ثبت‌نام نمایشی' : 'ورود نمایشی',
                        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    )),
                  TextButton(
                    onPressed: () => setState(() => register = !register),
                    child: Text(register ? 'قبلاً حساب ساخته‌ای؟ ورود' : 'حساب نداری؟ ثبت‌نام کن')),
                  const SizedBox(height: 10),
                  const Text('نسخه ۰.۲ • پیش‌نمایش رابط کاربری',
                    style: TextStyle(color: muted, fontSize: 12)),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

Widget _field(TextEditingController c, String label, IconData icon, {bool obscure = false}) =>
  Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: TextField(
      controller: c,
      obscureText: obscure,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, color: cyan),
        filled: true,
        fillColor: panel,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(15),
          borderSide: BorderSide.none),
      ),
    ),
  );

class MainPage extends StatefulWidget {
  const MainPage({super.key});
  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  int index = 0;
  final pages = const [ChatsPage(), GroupsPage(), ChannelsPage(), SettingsPage()];
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      backgroundColor: navy,
      titleSpacing: 16,
      title: const BrandLogo(width: 105),
      actions: [
        IconButton(onPressed: () => Navigator.push(context,
          MaterialPageRoute(builder: (_) => const SearchPage())),
          icon: const Icon(Icons.search, color: cyan)),
        IconButton(onPressed: () => Navigator.push(context,
          MaterialPageRoute(builder: (_) => const ProfilePage())),
          icon: const Icon(Icons.account_circle_outlined, color: cyan)),
      ],
    ),
    body: pages[index],
    bottomNavigationBar: NavigationBar(
      backgroundColor: panel,
      indicatorColor: purple.withOpacity(.25),
      selectedIndex: index,
      onDestinationSelected: (v) => setState(() => index = v),
      destinations: const [
        NavigationDestination(icon: Icon(Icons.chat_bubble_outline), label: 'گفت‌وگوها'),
        NavigationDestination(icon: Icon(Icons.groups_outlined), label: 'گروه‌ها'),
        NavigationDestination(icon: Icon(Icons.campaign_outlined), label: 'کانال‌ها'),
        NavigationDestination(icon: Icon(Icons.settings_outlined), label: 'تنظیمات'),
      ],
    ),
  );
}

class ChatsPage extends StatelessWidget {
  const ChatsPage({super.key});
  @override
  Widget build(BuildContext context) {
    final items = [
      ['پشتیبانی VEGA', 'به پیام‌رسان VEGA خوش آمدی!', 'آنلاین', 'V'],
      ['گفت‌وگوی نمونه', 'سلام! این یک پیام آزمایشی است.', '۲۰:۴۵', 'A'],
      ['دوستان', 'فایل تصویری ارسال شد', 'دیروز', 'D'],
    ];
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const _SectionTitle('پیام‌ها', subtitle: 'گفت‌وگوهای اخیر شما'),
        const SizedBox(height: 12),
        ...items.map((e) => Card(
          color: panel,
          elevation: 0,
          margin: const EdgeInsets.only(bottom: 10),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(17)),
          child: ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
            leading: CircleAvatar(
              backgroundColor: e[3] == 'V' ? purple.withOpacity(.25) : panel2,
              child: Text(e[3], style: const TextStyle(color: cyan, fontWeight: FontWeight.bold))),
            title: Text(e[0], style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text(e[1], maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: muted)),
            trailing: Text(e[2], style: const TextStyle(color: cyan, fontSize: 11)),
            onTap: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => ChatPage(title: e[0]))),
          ),
        )),
        const SizedBox(height: 10),
        const _InfoCard(icon: Icons.auto_awesome, title: 'نسخه ۰.۲',
          text: 'ساختار اولیه صفحات و مسیرهای اصلی برنامه آماده شده است.'),
      ],
    );
  }
}

class GroupsPage extends StatelessWidget {
  const GroupsPage({super.key});
  @override
  Widget build(BuildContext context) => _EmptyFeaturePage(
    icon: Icons.groups_2_outlined, title: 'گروه‌های VEGA',
    description: 'اینجا فهرست گروه‌ها، اعضا و مدیریت گروه‌ها نمایش داده می‌شود.',
    action: 'ایجاد گروه نمایشی');
}

class ChannelsPage extends StatelessWidget {
  const ChannelsPage({super.key});
  @override
  Widget build(BuildContext context) => _EmptyFeaturePage(
    icon: Icons.campaign_outlined, title: 'کانال‌ها',
    description: 'کانال‌های عمومی و خصوصی شما در این بخش قرار می‌گیرند.',
    action: 'ساخت کانال نمایشی');
}

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}
class _SettingsPageState extends State<SettingsPage> {
  bool notifications = true;
  bool dark = true;
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      const _SectionTitle('تنظیمات', subtitle: 'شخصی‌سازی تجربه VEGA'),
      const SizedBox(height: 14),
      _settingTile(Icons.person_outline, 'حساب کاربری', 'اطلاعات و پروفایل',
        () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ProfilePage()))),
      SwitchListTile(
        value: notifications, activeColor: cyan,
        onChanged: (v) => setState(() => notifications = v),
        secondary: const Icon(Icons.notifications_outlined, color: cyan),
        title: const Text('اعلان‌ها'), subtitle: const Text('اعلان‌های برنامه', style: TextStyle(color: muted))),
      SwitchListTile(
        value: dark, activeColor: cyan,
        onChanged: (v) => setState(() => dark = v),
        secondary: const Icon(Icons.dark_mode_outlined, color: cyan),
        title: const Text('حالت تیره'), subtitle: const Text('نمایش تیره برنامه', style: TextStyle(color: muted))),
      _settingTile(Icons.language, 'زبان', 'فارسی / English', () => _toast(context, 'انتخاب زبان در نسخه بعدی فعال می‌شود.')),
      _settingTile(Icons.shield_outlined, 'حریم خصوصی و امنیت', 'تنظیمات امنیتی حساب', () => _toast(context, 'این بخش در نسخه‌های بعدی تکمیل می‌شود.')),
      _settingTile(Icons.help_outline, 'پشتیبانی', 'ارتباط با تیم VEGA', () => _toast(context, 'پشتیبانی هنوز به سرور متصل نیست.')),
      const SizedBox(height: 20),
      const Center(child: Text('VEGA Messenger • 0.2.0', style: TextStyle(color: muted))),
    ],
  );
}

ListTile _settingTile(IconData icon, String title, String subtitle, VoidCallback onTap) =>
  ListTile(
    leading: Icon(icon, color: cyan), title: Text(title),
    subtitle: Text(subtitle, style: const TextStyle(color: muted)),
    trailing: const Icon(Icons.chevron_right, color: muted), onTap: onTap);

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('پروفایل من')),
    body: Center(child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        const CircleAvatar(radius: 46, backgroundColor: panel2,
          child: Icon(Icons.person, size: 48, color: cyan)),
        const SizedBox(height: 16),
        const Text('کاربر VEGA', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const Text('@VEGA_DEMO', style: TextStyle(color: muted)),
        const SizedBox(height: 18),
        const _InfoCard(icon: Icons.info_outline, title: 'حساب آزمایشی',
          text: 'این پروفایل در نسخه ۰.۲ محلی و نمایشی است و هنوز به حساب واقعی متصل نیست.'),
      ]),
    )),
  );
}

class SearchPage extends StatelessWidget {
  const SearchPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('جست‌وجو')),
    body: Padding(padding: const EdgeInsets.all(16),
      child: Column(children: [
        TextField(decoration: InputDecoration(
          hintText: 'جست‌وجوی شناسه، گروه یا کانال',
          prefixIcon: const Icon(Icons.search, color: cyan),
          filled: true, fillColor: panel,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none))),
        const SizedBox(height: 20),
        const Text('جست‌وجوی آنلاین پس از راه‌اندازی سرور فعال می‌شود.',
          style: TextStyle(color: muted)),
      ])),
  );
}

class ChatPage extends StatefulWidget {
  final String title;
  const ChatPage({super.key, required this.title});
  @override
  State<ChatPage> createState() => _ChatPageState();
}
class _ChatPageState extends State<ChatPage> {
  final controller = TextEditingController();
  final messages = <String>['سلام! به گفت‌وگوی آزمایشی VEGA خوش آمدی.'];
  @override
  void dispose() { controller.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(widget.title, style: const TextStyle(fontSize: 16)),
      const Text('گفت‌وگوی آزمایشی', style: TextStyle(fontSize: 11, color: muted)),
    ])),
    body: Column(children: [
      Expanded(child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          ...messages.map((m) => Align(
            alignment: Alignment.centerRight,
            child: Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
              constraints: const BoxConstraints(maxWidth: 290),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [Color(0xFF285A83), Color(0xFF55408B)]),
                borderRadius: BorderRadius.circular(17)),
              child: Text(m),
            ),
          )),
          const Align(alignment: Alignment.centerLeft,
            child: _InfoCard(icon: Icons.info_outline, title: 'حالت نمایشی',
              text: 'پیام‌ها فقط روی همین دستگاه و تا زمان بسته‌شدن برنامه نگهداری می‌شوند.')),
        ],
      )),
      SafeArea(child: Padding(
        padding: const EdgeInsets.fromLTRB(10, 6, 10, 10),
        child: Row(children: [
          IconButton(onPressed: () => _toast(context, 'ارسال فایل در نسخه بعدی فعال می‌شود.'),
            icon: const Icon(Icons.attach_file, color: cyan)),
          Expanded(child: TextField(controller: controller,
            decoration: InputDecoration(hintText: 'پیام بنویس...',
              filled: true, fillColor: panel,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(22), borderSide: BorderSide.none)))),
          IconButton(onPressed: () {
            final text = controller.text.trim();
            if (text.isEmpty) return;
            setState(() { messages.add(text); controller.clear(); });
          }, icon: const Icon(Icons.send_rounded, color: purple)),
        ]),
      )),
    ]),
  );
}

class _EmptyFeaturePage extends StatelessWidget {
  final IconData icon; final String title; final String description; final String action;
  const _EmptyFeaturePage({required this.icon, required this.title,
    required this.description, required this.action});
  @override
  Widget build(BuildContext context) => Center(child: Padding(
    padding: const EdgeInsets.all(28),
    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Container(width: 92, height: 92,
        decoration: BoxDecoration(color: purple.withOpacity(.15), borderRadius: BorderRadius.circular(28)),
        child: Icon(icon, size: 48, color: cyan)),
      const SizedBox(height: 20),
      Text(title, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
      const SizedBox(height: 10),
      Text(description, textAlign: TextAlign.center, style: const TextStyle(color: muted, height: 1.6)),
      const SizedBox(height: 20),
      OutlinedButton(onPressed: () => _toast(context, 'این قابلیت در نسخه‌های بعدی پیاده‌سازی می‌شود.'),
        child: Text(action)),
    ]),
  ));
}

class _SectionTitle extends StatelessWidget {
  final String title; final String subtitle;
  const _SectionTitle(this.title, {required this.subtitle});
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(title, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
    const SizedBox(height: 4),
    Text(subtitle, style: const TextStyle(color: muted)),
  ]);
}

class _InfoCard extends StatelessWidget {
  final IconData icon; final String title; final String text;
  const _InfoCard({required this.icon, required this.title, required this.text});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(15),
    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(17)),
    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(icon, color: cyan), const SizedBox(width: 11),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 5),
        Text(text, style: const TextStyle(color: muted, height: 1.45)),
      ])),
    ]),
  );
}

void _toast(BuildContext context, String message) =>
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
