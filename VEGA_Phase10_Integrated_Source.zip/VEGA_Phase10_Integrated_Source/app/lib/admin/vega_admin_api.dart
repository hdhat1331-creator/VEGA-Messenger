import 'dart:convert';
import 'package:http/http.dart' as http;

/// API client for VEGA administration. The owner secret is requested at runtime
/// and must never be hard-coded or persisted in source control.
class VegaAdminApi {
  VegaAdminApi({
    required String baseUrl,
    required Future<String?> Function() tokenProvider,
    http.Client? client,
  })  : _baseUrl = baseUrl.replaceFirst(RegExp(r'/$'), ''),
        _tokenProvider = tokenProvider,
        _client = client ?? http.Client();

  final String _baseUrl;
  final Future<String?> Function() _tokenProvider;
  final http.Client _client;
  String? _adminSession;

  bool get isUnlocked => _adminSession != null;

  Future<Map<String, dynamic>> unlockOwner(String secret) async {
    final data = await _request('POST', '/api/v1/admin/unlock', {
      'secret': secret,
    }, useAdminSession: false);
    final session = data['adminSession'];
    if (session is! String || session.isEmpty) {
      throw VegaAdminException('سرور مجوز مدیریتی معتبر برنگرداند.');
    }
    _adminSession = session;
    return data;
  }

  Future<Map<String, dynamic>> overview() =>
      _request('GET', '/api/v1/admin/overview', null);

  Future<List<Map<String, dynamic>>> searchUsers(String query) async {
    final data = await _request(
      'GET',
      '/api/v1/admin/users?query=${Uri.encodeQueryComponent(query)}',
      null,
    );
    return _items(data);
  }

  Future<void> setRole(String userId, String role) async {
    await _request('POST', '/api/v1/admin/roles', {
      'userId': userId,
      'role': role,
    });
  }

  Future<void> setBadge(String userId, String badge, {bool remove = false}) async {
    await _request('POST', '/api/v1/admin/badges', {
      'userId': userId,
      'badge': badge,
      'remove': remove,
    });
  }

  Future<void> setBan(String userId, {String reason = '', String? expiresAt}) async {
    await _request('POST', '/api/v1/admin/bans', {
      'userId': userId,
      'reason': reason,
      if (expiresAt != null) 'expiresAt': expiresAt,
    });
  }

  Future<void> unban(String userId) async {
    await _request('POST', '/api/v1/admin/bans', {
      'userId': userId,
      'remove': true,
    });
  }

  Future<List<Map<String, dynamic>>> reports() async =>
      _items(await _request('GET', '/api/v1/admin/reports', null));

  Future<void> updateReport(String id, String status) async {
    await _request('PATCH', '/api/v1/admin/reports', {
      'id': id,
      'status': status,
    });
  }

  Future<Map<String, dynamic>> testStats() =>
      _request('GET', '/api/v1/admin/test-stats', null);

  Future<void> updateTestStats(int views, int reactions) async {
    await _request('PUT', '/api/v1/admin/test-stats', {
      'views': views,
      'reactions': reactions,
    });
  }

  void lock() => _adminSession = null;

  List<Map<String, dynamic>> _items(Map<String, dynamic> data) {
    final value = data['items'];
    if (value is! List) return [];
    return value.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
  }

  Future<Map<String, dynamic>> _request(
    String method,
    String path,
    Map<String, dynamic>? body, {
    bool useAdminSession = true,
  }) async {
    final token = await _tokenProvider();
    if (token == null || token.isEmpty) {
      throw VegaAdminException('ابتدا وارد حساب VEGA شوید.');
    }

    final headers = <String, String>{
      'authorization': 'Bearer $token',
      'content-type': 'application/json',
      'accept': 'application/json',
    };
    if (useAdminSession && _adminSession != null) {
      headers['x-vega-admin-session'] = _adminSession!;
    }

    final uri = Uri.parse('$_baseUrl$path');
    late http.Response response;
    switch (method) {
      case 'GET':
        response = await _client.get(uri, headers: headers);
        break;
      case 'POST':
        response = await _client.post(uri, headers: headers, body: jsonEncode(body));
        break;
      case 'PUT':
        response = await _client.put(uri, headers: headers, body: jsonEncode(body));
        break;
      case 'PATCH':
        response = await _client.patch(uri, headers: headers, body: jsonEncode(body));
        break;
      default:
        throw UnsupportedError('Unsupported HTTP method.');
    }

    Map<String, dynamic> result;
    try {
      final parsed = jsonDecode(response.body);
      result = parsed is Map<String, dynamic> ? parsed : {};
    } catch (_) {
      result = {};
    }

    if (response.statusCode < 200 || response.statusCode >= 300) {
      if (response.statusCode == 401 || response.statusCode == 403) {
        _adminSession = null;
      }
      throw VegaAdminException(
        result['error']?.toString() ?? 'خطای سرور (${response.statusCode})',
        statusCode: response.statusCode,
      );
    }
    return result;
  }

  void close() {
    _adminSession = null;
    _client.close();
  }
}

class VegaAdminException implements Exception {
  VegaAdminException(this.message, {this.statusCode});
  final String message;
  final int? statusCode;

  @override
  String toString() => message;
}
