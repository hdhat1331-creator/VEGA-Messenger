import 'dart:convert';
import 'package:http/http.dart' as http;

/// Small typed API client for VEGA groups and channels.
class VegaCommunityApi {
  VegaCommunityApi({
    required String baseUrl,
    required Future<String?> Function() tokenProvider,
    http.Client? client,
  })  : _baseUrl = baseUrl.replaceFirst(RegExp(r'/$'), ''),
        _tokenProvider = tokenProvider,
        _client = client ?? http.Client();

  final String _baseUrl;
  final Future<String?> Function() _tokenProvider;
  final http.Client _client;

  Future<Map<String, dynamic>> createGroup({
    required String title,
    String description = '',
  }) =>
      _send('POST', '/api/v1/community/groups', {
        'title': title,
        'description': description,
      });

  Future<List<Map<String, dynamic>>> getGroups() =>
      _getItems('/api/v1/community/groups');

  Future<Map<String, dynamic>> createChannel({
    required String title,
    String description = '',
    String visibility = 'private',
  }) =>
      _send('POST', '/api/v1/community/channels', {
        'title': title,
        'description': description,
        'visibility': visibility,
      });

  Future<List<Map<String, dynamic>>> getChannels() =>
      _getItems('/api/v1/community/channels');

  Future<Map<String, dynamic>> joinByInvite(String code) =>
      _send('POST', '/api/v1/community/join', {'code': code});

  Future<Map<String, dynamic>> createInvite({
    required String type,
    required String id,
    int? maxUses,
    String? expiresAt,
  }) =>
      _send('POST', '/api/v1/community/invites', {
        'type': type,
        'id': id,
        if (maxUses != null) 'maxUses': maxUses,
        if (expiresAt != null) 'expiresAt': expiresAt,
      });

  Future<List<Map<String, dynamic>>> getMembers({
    required String type,
    required String id,
  }) =>
      _getItems('/api/v1/community/members?type=${Uri.encodeQueryComponent(type)}&id=${Uri.encodeQueryComponent(id)}');

  Future<Map<String, dynamic>> changeMemberRole({
    required String type,
    required String id,
    required String userId,
    required String role,
  }) =>
      _send('PATCH', '/api/v1/community/members/role', {
        'type': type,
        'id': id,
        'userId': userId,
        'role': role,
      });

  Future<Map<String, dynamic>> removeMember({
    required String type,
    required String id,
    required String userId,
  }) =>
      _send('DELETE', '/api/v1/community/members?type=${Uri.encodeQueryComponent(type)}&id=${Uri.encodeQueryComponent(id)}&userId=${Uri.encodeQueryComponent(userId)}', null);

  Future<Map<String, dynamic>> createChannelPost({
    required String channelId,
    String body = '',
    Map<String, dynamic>? mediaDescriptor,
  }) =>
      _send('POST', '/api/v1/community/posts', {
        'channelId': channelId,
        'body': body,
        if (mediaDescriptor != null) 'mediaDescriptor': mediaDescriptor,
      });

  Future<List<Map<String, dynamic>>> getChannelPosts(String channelId) =>
      _getItems('/api/v1/community/posts?channelId=${Uri.encodeQueryComponent(channelId)}');

  Future<Map<String, dynamic>> setPostReaction({
    required String postId,
    required String reaction,
    bool remove = false,
  }) =>
      _send('POST', '/api/v1/community/reactions', {
        'postId': postId,
        'reaction': reaction,
        'remove': remove,
      });

  Future<List<Map<String, dynamic>>> _getItems(String path) async {
    final result = await _send('GET', path, null);
    final items = result['items'];
    if (items is! List) return <Map<String, dynamic>>[];
    return items.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
  }

  Future<Map<String, dynamic>> _send(
    String method,
    String path,
    Map<String, dynamic>? body,
  ) async {
    final token = await _tokenProvider();
    if (token == null || token.isEmpty) {
      throw VegaCommunityException('ابتدا وارد حساب کاربری شوید.');
    }

    final uri = Uri.parse('$_baseUrl$path');
    final headers = <String, String>{
      'authorization': 'Bearer $token',
      'content-type': 'application/json',
      'accept': 'application/json',
    };

    late http.Response response;
    switch (method) {
      case 'GET':
        response = await _client.get(uri, headers: headers);
        break;
      case 'POST':
        response = await _client.post(uri, headers: headers, body: jsonEncode(body));
        break;
      case 'PATCH':
        response = await _client.patch(uri, headers: headers, body: jsonEncode(body));
        break;
      case 'DELETE':
        response = await _client.delete(uri, headers: headers);
        break;
      default:
        throw UnsupportedError('Unsupported method: $method');
    }

    Map<String, dynamic> data;
    try {
      final decoded = jsonDecode(response.body);
      data = decoded is Map<String, dynamic> ? decoded : <String, dynamic>{};
    } catch (_) {
      data = <String, dynamic>{};
    }

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw VegaCommunityException(
        data['error']?.toString() ?? 'خطای سرور (${response.statusCode})',
        statusCode: response.statusCode,
      );
    }
    return data;
  }

  void close() => _client.close();
}

class VegaCommunityException implements Exception {
  VegaCommunityException(this.message, {this.statusCode});
  final String message;
  final int? statusCode;

  @override
  String toString() => message;
}
