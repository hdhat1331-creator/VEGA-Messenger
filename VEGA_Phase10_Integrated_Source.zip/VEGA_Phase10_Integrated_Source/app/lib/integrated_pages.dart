import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'community/community_api.dart';
import 'admin/vega_admin_api.dart';
import 'sync/vega_sync_api.dart';

const _vBg = Color(0xFF090D1C);
const _vPanel = Color(0xFF151B32);
const _vPurple = Color(0xFF8B5CF6);
const _vCyan = Color(0xFF35D5D0);

class VegaProfilePage extends StatefulWidget {
  const VegaProfilePage({super.key, required this.baseUrl, required this.tokenProvider});
  final String baseUrl;
  final Future<String?> Function() tokenProvider;
  @override
  State<VegaProfilePage> createState() => _VegaProfilePageState();
}

class _VegaProfilePageState extends State<VegaProfilePage> {
  Map<String, dynamic>? _user;
  bool _busy = true;
  String? _error;
  final _name = TextEditingController();
  final _bio = TextEditingController();
  String _privacy = 'everyone';

  Future<void> _load() async {
    setState(() { _busy = true; _error = null; });
    try {
      final token = await widget.tokenProvider();
      final response = await _get(widget.baseUrl, '/api/v1/me', token);
      final user = Map<String, dynamic>.from(response['user'] as Map);
      _user = user;
      _name.text = (user['display_name'] ?? user['displayName'] ?? '').toString();
      _bio.text = (user['bio'] ?? '').toString();
      _privacy = (user['last_seen_privacy'] ?? 'everyone').toString();
    } catch (e) { _error = e.toString(); }
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _save() async {
    try {
      final token = await widget.tokenProvider();
      await _send(widget.baseUrl, '/api/v1/me', token, {
        'displayName': _name.text.trim(),
        'bio': _bio.text.trim(),
        'lastSeenPrivacy': _privacy,
      }, method: 'PATCH');
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('پروفایل ذخیره شد.')));
      await _load();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    }
  }

  @override
  void initState() { super.initState(); _load(); }
  @override
  void dispose() { _name.dispose(); _bio.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: _vBg,
    appBar: AppBar(title: const Text('پروفایل')),
    body: _busy ? const Center(child: CircularProgressIndicator()) : _error != null
      ? _ErrorView(message: _error!, retry: _load)
      : ListView(padding: const EdgeInsets.all(18), children: [
          const CircleAvatar(radius: 42, backgroundColor: _vPanel, child: Icon(Icons.person, size: 42, color: _vCyan)),
          const SizedBox(height: 12),
          Center(child: Text('@${_user?['username'] ?? ''}', style: const TextStyle(color: _vCyan))),
          const SizedBox(height: 22),
          TextField(controller: _name, maxLength: 20, decoration: const InputDecoration(labelText: 'نام نمایشی')),
          const SizedBox(height: 12),
          TextField(controller: _bio, maxLength: 160, maxLines: 3, decoration: const InputDecoration(labelText: 'درباره من')),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            value: _privacy,
            decoration: const InputDecoration(labelText: 'نمایش آخرین بازدید'),
            items: const [
              DropdownMenuItem(value: 'everyone', child: Text('همه')),
              DropdownMenuItem(value: 'contacts', child: Text('مخاطبین')),
              DropdownMenuItem(value: 'nobody', child: Text('هیچ‌کس')),
            ],
            onChanged: (v) { if (v != null) setState(() => _privacy = v); },
          ),
          const SizedBox(height: 20),
          FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save), label: const Text('ذخیره تغییرات')),
        ]),
  );
}

class VegaSettingsPage extends StatefulWidget {
  const VegaSettingsPage({super.key, required this.baseUrl, required this.tokenProvider});
  final String baseUrl;
  final Future<String?> Function() tokenProvider;
  @override
  State<VegaSettingsPage> createState() => _VegaSettingsPageState();
}

class _VegaSettingsPageState extends State<VegaSettingsPage> {
  late final VegaSyncApi _api = VegaSyncApi(baseUrl: widget.baseUrl, readAccessToken: widget.tokenProvider);
  bool _busy = true;
  bool _direct = true, _groups = true, _channels = true, _sound = true;
  String? _error;

  Future<void> _load() async {
    setState(() { _busy = true; _error = null; });
    try {
      final p = await _api.getNotificationPreferences();
      _direct = (p['direct_messages'] ?? p['directMessages'] ?? true) == true || (p['direct_messages'] == 1);
      _groups = (p['group_messages'] ?? p['groupMessages'] ?? true) == true || (p['group_messages'] == 1);
      _channels = (p['channel_posts'] ?? p['channelPosts'] ?? true) == true || (p['channel_posts'] == 1);
      _sound = (p['sound_enabled'] ?? p['soundEnabled'] ?? true) == true || (p['sound_enabled'] == 1);
    } catch (e) { _error = e.toString(); }
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _save() async {
    try {
      await _api.updateNotificationPreferences(directMessages: _direct, groupMessages: _groups, channelPosts: _channels, soundEnabled: _sound);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تنظیمات اعلان ذخیره شد.')));
    } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString()))); }
  }

  @override
  void initState() { super.initState(); _load(); }
  @override
  void dispose() { _api.close(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: _vBg,
    appBar: AppBar(title: const Text('تنظیمات')),
    body: _busy ? const Center(child: CircularProgressIndicator()) : ListView(padding: const EdgeInsets.all(16), children: [
      if (_error != null) Text('تنظیم اعلان‌ها در دسترس نیست: $_error', style: const TextStyle(color: Colors.orangeAccent)),
      const Text('اعلان‌ها', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
      SwitchListTile(title: const Text('پیام‌های خصوصی'), value: _direct, onChanged: (v) => setState(() => _direct = v)),
      SwitchListTile(title: const Text('پیام‌های گروهی'), value: _groups, onChanged: (v) => setState(() => _groups = v)),
      SwitchListTile(title: const Text('پست‌های کانال'), value: _channels, onChanged: (v) => setState(() => _channels = v)),
      SwitchListTile(title: const Text('صدای اعلان'), value: _sound, onChanged: (v) => setState(() => _sound = v)),
      const SizedBox(height: 12),
      FilledButton(onPressed: _save, child: const Text('ذخیره تنظیمات')),
      const Divider(height: 36),
      ListTile(leading: const Icon(Icons.admin_panel_settings, color: _vCyan), title: const Text('پنل مدیریت'), subtitle: const Text('فقط برای حساب‌های دارای دسترسی'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => VegaAdminPage(baseUrl: widget.baseUrl, tokenProvider: widget.tokenProvider)))),
      const ListTile(leading: Icon(Icons.lock_outline, color: _vCyan), title: Text('امنیت حساب'), subtitle: Text('اطلاعات ورود در فضای امن دستگاه نگهداری می‌شود.')),
    ]),
  );
}

class VegaCommunityPage extends StatefulWidget {
  const VegaCommunityPage({super.key, required this.baseUrl, required this.tokenProvider});
  final String baseUrl;
  final Future<String?> Function() tokenProvider;
  @override
  State<VegaCommunityPage> createState() => _VegaCommunityPageState();
}

class _VegaCommunityPageState extends State<VegaCommunityPage> with SingleTickerProviderStateMixin {
  late final VegaCommunityApi _api = VegaCommunityApi(baseUrl: widget.baseUrl, tokenProvider: widget.tokenProvider);
  late final TabController _tabs = TabController(length: 2, vsync: this);
  List<Map<String, dynamic>> _groups = [], _channels = [];
  bool _busy = true;
  String? _error;

  Future<void> _load() async {
    setState(() { _busy = true; _error = null; });
    try {
      final results = await Future.wait([_api.getGroups(), _api.getChannels()]);
      _groups = results[0]; _channels = results[1];
    } catch (e) { _error = e.toString(); }
    if (mounted) setState(() => _busy = false);
  }

  Future<String?> _ask(String title, String hint) async {
    final c = TextEditingController();
    final value = await showDialog<String>(context: context, builder: (ctx) => AlertDialog(
      backgroundColor: _vPanel, title: Text(title),
      content: TextField(controller: c, autofocus: true, decoration: InputDecoration(hintText: hint)),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('انصراف')), FilledButton(onPressed: () => Navigator.pop(ctx, c.text.trim()), child: const Text('تأیید'))],
    ));
    c.dispose();
    return value;
  }

  Future<void> _create(bool channel) async {
    final title = await _ask(channel ? 'ساخت کانال' : 'ساخت گروه', 'نام');
    if (title == null || title.trim().isEmpty) return;
    try {
      if (channel) {
        await _api.createChannel(title: title, visibility: 'public');
      } else {
        await _api.createGroup(title: title);
      }
      await _load();
    } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString()))); }
  }

  Future<void> _join() async {
    final code = await _ask('پیوستن با کد دعوت', 'کد دعوت');
    if (code == null || code.isEmpty) return;
    try { await _api.joinByInvite(code); await _load(); }
    catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString()))); }
  }

  Future<void> _openChannel(Map<String, dynamic> channel) async {
    final id = channel['id']?.toString() ?? '';
    if (id.isEmpty) return;
    await Navigator.push(context, MaterialPageRoute(builder: (_) => VegaChannelPage(api: _api, channel: channel)));
    if (mounted) _load();
  }

  @override
  void initState() { super.initState(); _load(); }
  @override
  void dispose() { _tabs.dispose(); _api.close(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: _vBg,
    appBar: AppBar(title: const Text('گروه‌ها و کانال‌ها'), actions: [
      IconButton(tooltip: 'پیوستن با کد', onPressed: _join, icon: const Icon(Icons.link)),
      IconButton(tooltip: 'ساخت گروه', onPressed: () => _create(false), icon: const Icon(Icons.group_add)),
      IconButton(tooltip: 'ساخت کانال', onPressed: () => _create(true), icon: const Icon(Icons.campaign)),
    ], bottom: TabBar(controller: _tabs, tabs: const [Tab(text: 'گروه‌ها'), Tab(text: 'کانال‌ها')])),
    body: _busy ? const Center(child: CircularProgressIndicator()) : _error != null ? _ErrorView(message: _error!, retry: _load) : TabBarView(controller: _tabs, children: [
      _CommunityList(items: _groups, icon: Icons.groups, empty: 'هنوز گروهی نساخته‌اید یا عضو نشده‌اید.', onTap: (item) => _showInfo(context, item)),
      _CommunityList(items: _channels, icon: Icons.campaign, empty: 'هنوز کانالی ندارید.', onTap: _openChannel),
    ]),
  );
}

class VegaChannelPage extends StatefulWidget {
  const VegaChannelPage({super.key, required this.api, required this.channel});
  final VegaCommunityApi api;
  final Map<String, dynamic> channel;
  @override
  State<VegaChannelPage> createState() => _VegaChannelPageState();
}
class _VegaChannelPageState extends State<VegaChannelPage> {
  List<Map<String, dynamic>> _posts = [];
  bool _busy = true;
  Future<void> _load() async {
    try { _posts = await widget.api.getChannelPosts(widget.channel['id'].toString()); }
    catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString()))); }
    if (mounted) setState(() => _busy = false);
  }
  Future<void> _post() async {
    final c = TextEditingController();
    final text = await showDialog<String>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('پست جدید'), content: TextField(controller: c, maxLines: 4, decoration: const InputDecoration(hintText: 'متن پست')),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('انصراف')), FilledButton(onPressed: () => Navigator.pop(ctx, c.text.trim()), child: const Text('انتشار'))],
    ));
    c.dispose();
    if (text == null || text.isEmpty) return;
    try { await widget.api.createChannelPost(channelId: widget.channel['id'].toString(), body: text); await _load(); }
    catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString()))); }
  }
  @override
  void initState() { super.initState(); _load(); }
  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: _vBg,
    appBar: AppBar(title: Text(widget.channel['title']?.toString() ?? 'کانال'), actions: [IconButton(onPressed: _post, icon: const Icon(Icons.add))]),
    body: _busy ? const Center(child: CircularProgressIndicator()) : _posts.isEmpty ? const Center(child: Text('هنوز پستی منتشر نشده است.')) : ListView.builder(
      padding: const EdgeInsets.all(12), itemCount: _posts.length,
      itemBuilder: (_, i) { final p = _posts[i]; return Card(color: _vPanel, child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(p['body']?.toString() ?? '', style: const TextStyle(fontSize: 15)),
        const SizedBox(height: 8),
        Row(children: [Text(p['created_at']?.toString() ?? '', style: const TextStyle(color: Colors.white54, fontSize: 11)), const Spacer(), IconButton(onPressed: () async { await widget.api.setPostReaction(postId: p['id'].toString(), reaction: 'like'); await _load(); }, icon: const Icon(Icons.favorite_border, color: _vCyan))]),
      ]))); },
    ),
  );
}

class VegaAdminPage extends StatefulWidget {
  const VegaAdminPage({super.key, required this.baseUrl, required this.tokenProvider});
  final String baseUrl;
  final Future<String?> Function() tokenProvider;
  @override
  State<VegaAdminPage> createState() => _VegaAdminPageState();
}
class _VegaAdminPageState extends State<VegaAdminPage> {
  late final VegaAdminApi _api = VegaAdminApi(baseUrl: widget.baseUrl, tokenProvider: widget.tokenProvider);
  final _secret = TextEditingController(), _query = TextEditingController();
  Map<String, dynamic>? _stats;
  List<Map<String, dynamic>> _users = [];
  String? _error;
  bool _busy = false;
  Future<void> _unlock() async {
    setState(() { _busy = true; _error = null; });
    try { await _api.unlockOwner(_secret.text); _stats = await _api.overview(); }
    catch (e) { _error = e.toString(); }
    if (mounted) setState(() => _busy = false);
  }
  Future<void> _tryExistingAdmin() async {
    try {
      _stats = await _api.overview();
      if (mounted) setState(() {});
    } catch (_) {
      // A regular account will see the owner unlock prompt instead.
    }
  }
  Future<void> _search() async {
    if (_query.text.trim().isEmpty) return;
    try { _users = await _api.searchUsers(_query.text.trim()); setState(() {}); }
    catch (e) { setState(() => _error = e.toString()); }
  }
  Future<void> _grant(Map<String, dynamic> user, String role) async {
    final id = user['id']?.toString() ?? '';
    if (id.isEmpty) return;
    try {
      await _api.setRole(id, role);
      if (role == 'admin') {
        await _api.setBadge(id, 'ADMIN');
      } else {
        await _api.setBadge(id, 'ADMIN', remove: true);
      }
      await _search();
    }
    catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString()))); }
  }
  @override
  void initState() { super.initState(); _tryExistingAdmin(); }
  @override
  void dispose() { _secret.dispose(); _query.dispose(); _api.close(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: _vBg, appBar: AppBar(title: const Text('مدیریت VEGA')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      if (!_api.isUnlocked) ...[
        const Text('ورود مالک به پنل مدیریت'),
        TextField(controller: _secret, obscureText: true, decoration: const InputDecoration(labelText: 'رمز مدیریت')),
        const SizedBox(height: 12),
        FilledButton(onPressed: _busy ? null : _unlock, child: const Text('باز کردن پنل')),
      ] else ...[
        if (_stats != null) Card(color: _vPanel, child: Padding(padding: const EdgeInsets.all(14), child: Text('کاربران: ${_stats!['users'] ?? 0}   گروه‌ها: ${_stats!['groups'] ?? 0}   کانال‌ها: ${_stats!['channels'] ?? 0}   گزارش‌ها: ${_stats!['openReports'] ?? 0}'))),
        const SizedBox(height: 12),
        TextField(controller: _query, decoration: InputDecoration(labelText: 'جست‌وجوی کاربر با شناسه یا نام کاربری', suffixIcon: IconButton(onPressed: _search, icon: const Icon(Icons.search))), onSubmitted: (_) => _search()),
        ..._users.map((u) => Card(color: _vPanel, child: ListTile(title: Text(u['display_name']?.toString() ?? u['username']?.toString() ?? ''), subtitle: Text('ID: ${u['id']}'), trailing: PopupMenuButton<String>(onSelected: (r) => _grant(u, r), itemBuilder: (_) => const [PopupMenuItem(value: 'admin', child: Text('ادمین')), PopupMenuItem(value: 'moderator', child: Text('ناظر')), PopupMenuItem(value: 'support', child: Text('پشتیبانی'))])))),
      ],
      if (_error != null) Padding(padding: const EdgeInsets.all(8), child: Text(_error!, style: const TextStyle(color: Colors.orangeAccent))),
      if (_busy) const LinearProgressIndicator(),
    ]),
  );
}

class _CommunityList extends StatelessWidget {
  const _CommunityList({required this.items, required this.icon, required this.empty, required this.onTap});
  final List<Map<String, dynamic>> items;
  final IconData icon;
  final String empty;
  final ValueChanged<Map<String, dynamic>> onTap;
  @override
  Widget build(BuildContext context) => items.isEmpty ? Center(child: Text(empty, style: const TextStyle(color: Colors.white60))) : ListView.builder(
    itemCount: items.length,
    itemBuilder: (_, i) { final item = items[i]; return ListTile(leading: Icon(icon, color: _vCyan), title: Text(item['title']?.toString() ?? ''), subtitle: Text('${item['description'] ?? ''}'), onTap: () => onTap(item)); },
  );
}

class _ErrorView extends StatelessWidget {
  const _ErrorView({required this.message, required this.retry});
  final String message;
  final VoidCallback retry;
  @override
  Widget build(BuildContext context) => Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [Text(message, textAlign: TextAlign.center), const SizedBox(height: 12), FilledButton(onPressed: retry, child: const Text('تلاش دوباره'))])));
}

Future<Map<String, dynamic>> _get(String base, String path, String? token) async {
  final response = await _httpGet(Uri.parse('$base$path'), token);
  return response;
}
Future<Map<String, dynamic>> _send(String base, String path, String? token, Map<String, dynamic> data, {String method = 'POST'}) async {
  final client = _pageClient;
  final uri = Uri.parse('$base$path');
  final headers = {'content-type': 'application/json', 'accept': 'application/json', if (token != null) 'authorization': 'Bearer $token'};
  final response = method == 'PATCH' ? await client.patch(uri, headers: headers, body: _encode(data)) : await client.post(uri, headers: headers, body: _encode(data));
  return _decode(response.statusCode, response.body);
}
String _encode(Map<String, dynamic> value) => jsonEncode(value);

final http.Client _pageClient = http.Client();
Future<Map<String, dynamic>> _httpGet(Uri uri, String? token) async {
  final response = await _pageClient.get(uri, headers: {'accept': 'application/json', if (token != null) 'authorization': 'Bearer $token'});
  return _decode(response.statusCode, response.body);
}
Map<String, dynamic> _decode(int status, String body) {
  Map<String, dynamic> data = {};
  try { final v = jsonDecode(body); if (v is Map<String, dynamic>) data = v; } catch (_) {}
  if (status < 200 || status >= 300) throw Exception(data['error']?.toString() ?? 'خطای سرور ($status)');
  return data;
}
void _showInfo(BuildContext context, Map<String, dynamic> item) {
  showDialog<void>(context: context, builder: (ctx) => AlertDialog(
    title: Text(item['title']?.toString() ?? 'گروه'),
    content: SelectableText('شناسه: ${item['id'] ?? ''}\nنقش شما: ${item['role'] ?? 'عضو'}'),
    actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('بستن'))],
  ));
}
