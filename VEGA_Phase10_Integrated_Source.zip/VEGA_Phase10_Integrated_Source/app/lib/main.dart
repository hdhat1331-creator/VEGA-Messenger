import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'integrated_pages.dart';

// Test environment only. The production Worker remains unchanged.
const apiBaseUrl = 'https://vega-server-test.v58073149.workers.dev';
const bg = Color(0xFF090D1C);
const panel = Color(0xFF151B32);
const purple = Color(0xFF8B5CF6);
const cyan = Color(0xFF35D5D0);
const _secureStorage = FlutterSecureStorage();

void main() => runApp(const VegaApp());

class Api {
  static String? token;
  static String? currentUserId;
  static final http.Client _client = http.Client();

  static String? userIdFrom(dynamic value) {
    if (value is! Map) return null;
    final raw = value['id'] ?? value['user_id'] ?? value['userId'] ?? value['sub'];
    final id = raw?.toString().trim();
    return (id == null || id.isEmpty) ? null : id;
  }

  static Future<Map<String, dynamic>> request(
    String path, {
    String method = 'GET',
    Map<String, dynamic>? data,
  }) async {
    final uri = Uri.parse('$apiBaseUrl$path');
    final headers = <String, String>{
      'accept': 'application/json',
      'content-type': 'application/json; charset=utf-8',
      if (token != null) 'authorization': 'Bearer $token',
    };

    late http.Response response;
    final body = data == null ? null : jsonEncode(data);
    switch (method) {
      case 'GET':
        response = await _client.get(uri, headers: headers).timeout(
              const Duration(seconds: 30),
            );
        break;
      case 'POST':
        response = await _client
            .post(uri, headers: headers, body: body ?? '{}')
            .timeout(const Duration(seconds: 30));
        break;
      case 'PATCH':
        response = await _client
            .patch(uri, headers: headers, body: body ?? '{}')
            .timeout(const Duration(seconds: 30));
        break;
      case 'DELETE':
        response = await _client
            .delete(uri, headers: headers, body: body)
            .timeout(const Duration(seconds: 30));
        break;
      default:
        throw ArgumentError('روش درخواست پشتیبانی نمی‌شود: $method');
    }

    Map<String, dynamic> decoded;
    try {
      final value = jsonDecode(response.body);
      decoded = value is Map<String, dynamic> ? value : <String, dynamic>{};
    } catch (_) {
      decoded = <String, dynamic>{};
    }

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception(
        decoded['error']?.toString() ??
            'خطای ارتباط با سرور (${response.statusCode})',
      );
    }
    return decoded;
  }
}

class VegaApp extends StatelessWidget {
  const VegaApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'VEGA',
        debugShowCheckedModeBanner: false,
        theme: ThemeData.dark().copyWith(
          scaffoldBackgroundColor: bg,
          colorScheme: const ColorScheme.dark(
            primary: purple,
            secondary: cyan,
          ),
          appBarTheme: const AppBarTheme(
            backgroundColor: bg,
            foregroundColor: Colors.white,
            elevation: 0,
          ),
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: panel,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide.none,
            ),
          ),
        ),
        home: const Gate(),
      );
}

class Gate extends StatefulWidget {
  const Gate({super.key});
  @override
  State<Gate> createState() => _GateState();
}

class _GateState extends State<Gate> {
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    super.dispose();
  }

  Future<void> _load() async {
    String? saved = await _secureStorage.read(key: 'vega_access_token');
    // One-time migration from the older non-secure token location.
    if (saved == null) {
      final prefs = await SharedPreferences.getInstance();
      saved = prefs.getString('token');
      if (saved != null && saved.isNotEmpty) {
        await _secureStorage.write(key: 'vega_access_token', value: saved);
        await prefs.remove('token');
      }
    }
    Api.token = saved;
    Api.currentUserId = await _secureStorage.read(key: 'vega_user_id');
    if (saved != null && saved.isNotEmpty) {
      try {
        final me = await Api.request('/api/v1/me');
        Api.currentUserId = Api.userIdFrom(me['user']);
        if (Api.currentUserId != null) {
          await _secureStorage.write(key: 'vega_user_id', value: Api.currentUserId!);
        }
      } catch (e) {
        // A temporary network failure must not erase a valid local session.
        // Clear credentials only when the server explicitly rejects the token.
        final message = e.toString();
        if (message.contains('(401)') || message.contains('ابتدا وارد حساب شوید')) {
          await _secureStorage.delete(key: 'vega_access_token');
          await _secureStorage.delete(key: 'vega_user_id');
          Api.token = null;
          Api.currentUserId = null;
        }
      }
    }
    if (mounted) setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    return Api.token == null ? const AuthPage() : const HomePage();
  }
}

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});
  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  final _user = TextEditingController();
  final _name = TextEditingController();
  final _pass = TextEditingController();
  bool _register = false;
  bool _busy = false;
  bool _hidePassword = true;
  String? _error;

  @override
  void dispose() {
    _user.dispose();
    _name.dispose();
    _pass.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final username = _user.text.trim();
    final password = _pass.text;
    final displayName = _name.text.trim();

    if (!RegExp(r'^[a-zA-Z0-9_]{5,24}$').hasMatch(username)) {
      setState(() => _error = 'نام کاربری باید ۵ تا ۲۴ نویسه انگلیسی، عدد یا _ باشد.');
      return;
    }
    if (password.length < 10 || password.length > 256) {
      setState(() => _error = 'رمز عبور باید حداقل ۱۰ نویسه داشته باشد.');
      return;
    }
    if (_register && (displayName.length < 2 || displayName.length > 20)) {
      setState(() => _error = 'نام نمایشی را وارد کن (حداکثر ۲۰ نویسه).');
      return;
    }

    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final result = await Api.request(
        _register ? '/api/v1/register' : '/api/v1/login',
        method: 'POST',
        data: <String, dynamic>{
          'username': username,
          'password': password,
          if (_register) 'displayName': displayName,
        },
      );
      final newToken = result['token']?.toString();
      if (newToken == null || newToken.isEmpty) {
        throw Exception('پاسخ ورود از سرور معتبر نیست.');
      }
      await _secureStorage.write(key: 'vega_access_token', value: newToken);
      Api.token = newToken;
      final user = result['user'];
      Api.currentUserId = Api.userIdFrom(user);
      if (Api.currentUserId == null) {
        try {
          final me = await Api.request('/api/v1/me');
          final current = me['user'];
          Api.currentUserId = Api.userIdFrom(current);
        } catch (_) {
          // Keep the session; the next authenticated refresh can retry.
        }
      }
      if (Api.currentUserId != null) {
        await _secureStorage.write(key: 'vega_user_id', value: Api.currentUserId!);
      }
      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const HomePage()),
      );
    } catch (e) {
      if (mounted) setState(() => _error = _friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  String _friendlyError(Object error) => error.toString().replaceFirst('Exception: ', '');

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 440),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Image.asset(
                      'assets/images/vega_full_logo.jpg',
                      width: 220,
                      height: 117,
                      fit: BoxFit.contain,
                      errorBuilder: (_, __, ___) => const Icon(
                        Icons.stars_rounded,
                        size: 76,
                        color: cyan,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      _register ? 'ساخت حساب' : 'ورود به حساب',
                      style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(height: 22),
                    TextField(
                      controller: _user,
                      textCapitalization: TextCapitalization.none,
                      autocorrect: false,
                      decoration: const InputDecoration(labelText: 'نام کاربری'),
                    ),
                    if (_register) ...[
                      const SizedBox(height: 12),
                      TextField(
                        controller: _name,
                        maxLength: 20,
                        decoration: const InputDecoration(labelText: 'نام نمایشی'),
                      ),
                    ],
                    const SizedBox(height: 12),
                    TextField(
                      controller: _pass,
                      obscureText: _hidePassword,
                      decoration: InputDecoration(
                        labelText: 'رمز عبور',
                        suffixIcon: IconButton(
                          onPressed: () => setState(() => _hidePassword = !_hidePassword),
                          icon: Icon(_hidePassword ? Icons.visibility : Icons.visibility_off),
                        ),
                      ),
                    ),
                    if (_error != null)
                      Padding(
                        padding: const EdgeInsets.only(top: 12),
                        child: Text(
                          _error!,
                          textAlign: TextAlign.center,
                          style: const TextStyle(color: Colors.redAccent),
                        ),
                      ),
                    const SizedBox(height: 20),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton(
                        onPressed: _busy ? null : _submit,
                        child: Text(_busy ? 'لطفاً صبر کن…' : _register ? 'ثبت‌نام' : 'ورود'),
                      ),
                    ),
                    TextButton(
                      onPressed: _busy
                          ? null
                          : () => setState(() {
                                _register = !_register;
                                _error = null;
                              }),
                      child: Text(_register ? 'قبلاً حساب ساخته‌ام' : 'ایجاد حساب جدید'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with WidgetsBindingObserver {
  List<Map<String, dynamic>> _conversations = [];
  final Set<String> _selected = <String>{};
  final Set<String> _muted = <String>{};
  final Map<String, int> _hiddenAt = <String, int>{};
  final Map<String, int> _cutoffs = <String, int>{};
  final TextEditingController _search = TextEditingController();
  String _category = 'همه';
  String? _error;
  bool _loading = true;
  bool _fetchingHome = false;
  Timer? _homePollTimer;
  DateTime? _lastHeartbeatAt;
  Timer? _holdTimer;
  String? _holdingId;
  bool _longPressActivated = false;

  String get _accountKey => (Api.currentUserId ?? 'unknown').replaceAll(RegExp(r'[^a-zA-Z0-9_-]'), '_');
  String _hiddenKey(String id) => 'vega_hidden_${_accountKey}_$id';
  String _cutoffKey(String id) => 'vega_cutoff_${_accountKey}_$id';
  String _mutedKey(String id) => 'vega_muted_${_accountKey}_$id';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
    _startHomePolling();
  }

  void _startHomePolling() {
    _homePollTimer?.cancel();
    _homePollTimer = Timer.periodic(const Duration(seconds: 4), (_) {
      if (mounted && WidgetsBinding.instance.lifecycleState == AppLifecycleState.resumed) {
        _load(silent: true);
      }
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _load(silent: true);
      _startHomePolling();
    } else {
      _homePollTimer?.cancel();
    }
  }

  Future<void> _load({bool silent = false}) async {
    if (_fetchingHome) return;
    _fetchingHome = true;
    if (!silent && mounted) setState(() { _loading = true; _error = null; });
    try {
      final prefs = await SharedPreferences.getInstance();
      final now = DateTime.now();
      if (_lastHeartbeatAt == null || now.difference(_lastHeartbeatAt!).inSeconds >= 60) {
        try {
          await Api.request('/api/v1/presence/heartbeat', method: 'POST');
          _lastHeartbeatAt = now;
        } catch (_) {
          // Presence is best-effort; it must not block chat loading.
        }
      }
      final result = await Api.request('/api/v1/conversations');
      final rawRows = result['conversations'] ?? result['items'] ?? result['data'];
      final rows = (rawRows as List? ?? const [])
          .whereType<Map>()
          .map((row) => Map<String, dynamic>.from(row))
          .where((row) => row['type'] == 'private' || row['type'] == 'group')
          .toList();

      final hidden = <String, int>{};
      final hiddenCutoffs = <String, int>{};
      final muted = <String>{};
      for (final row in rows) {
        final id = row['id']?.toString() ?? '';
        if (id.isEmpty) continue;
        final cutoff = prefs.getInt(_cutoffKey(id));
        if (cutoff != null) hiddenCutoffs[id] = cutoff;
        final deletedAt = prefs.getInt(_hiddenKey(id));
        if (deletedAt != null) hidden[id] = deletedAt;
        if (prefs.getBool(_mutedKey(id)) ?? false) muted.add(id);
      }

      // A locally hidden conversation reappears after a newer incoming message.
      // Check hidden threads at most once per 30 seconds, not on every 4-second home poll.
      final reopened = <String>{};
      final hiddenCheckKey = 'vega_hidden_check_$_accountKey';
      final lastHiddenCheck = prefs.getInt(hiddenCheckKey) ?? 0;
      final nowMillis = DateTime.now().millisecondsSinceEpoch;
      final shouldCheckHidden = nowMillis - lastHiddenCheck >= 30000;
      if (shouldCheckHidden) {
        await prefs.setInt(hiddenCheckKey, nowMillis);
      }
      if (shouldCheckHidden) for (final entry in hidden.entries) {
        try {
          final messageResult = await Api.request('/api/v1/conversations/${entry.key}/messages');
          final messages = (messageResult['items'] ?? messageResult['messages'] ?? messageResult['data'] ?? const []) as List? ?? const [];
          var newestMillis = 0;
          for (final item in messages.whereType<Map>()) {
            final rawTime = item['created_at'] ?? item['createdAt'] ?? item['timestamp'];
            int value = rawTime is num ? rawTime.toInt() : int.tryParse(rawTime?.toString() ?? '') ?? 0;
            if (value == 0) value = DateTime.tryParse(rawTime?.toString() ?? '')?.millisecondsSinceEpoch ?? 0;
            final millis = value > 1000000000000 ? value : value * 1000;
            if (millis > newestMillis) newestMillis = millis;
          }
          if (newestMillis > entry.value) {
            reopened.add(entry.key);
            await prefs.remove(_hiddenKey(entry.key));
          }
        } catch (_) {
          // Keep the local hidden state if the network is temporarily unavailable.
        }
      }
      hidden.removeWhere((id, _) => reopened.contains(id));
      final visible = rows.where((row) => !hidden.containsKey(row['id']?.toString() ?? '')).toList();
      if (mounted) {
        setState(() {
          _conversations = visible;
          _muted..clear()..addAll(muted);
          _hiddenAt..clear()..addAll(hidden);
          _cutoffs..clear()..addAll(hiddenCutoffs);
          _selected.removeWhere((id) => !visible.any((row) => row['id']?.toString() == id));
          _error = null;
        });
      }
    } catch (e) {
      if (mounted && !silent) setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      _fetchingHome = false;
      if (mounted) setState(() => _loading = false);
    }
  }

  void _openOrSelect(Map<String, dynamic> item) {
    final id = item['id']?.toString() ?? '';
    if (id.isEmpty) return;
    if (_selected.isNotEmpty) {
      setState(() => _selected.contains(id) ? _selected.remove(id) : _selected.add(id));
      return;
    }
    _openChat(id, item['title']?.toString().trim() ?? '', item['type']?.toString() ?? 'private');
  }

  void _openChat(String id, String title, String type) {
    final cutoff = _cutoffs[id];
    Navigator.push(context, MaterialPageRoute(builder: (_) => ChatPage(id: id, title: title, type: type, historyCutoff: cutoff)));
  }

  Future<void> _deleteSelected() async {
    if (_selected.isEmpty) return;
    final ids = _selected.toList();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: panel,
        title: const Text('حذف گفتگوها؟'),
        content: Text('${ids.length} گفتگو فقط از فهرست این حساب حذف می‌شود. اگر پیام تازه‌ای دریافت شود، دوباره نمایش داده خواهد شد.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('انصراف')),
          FilledButton.tonal(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('حذف')),
        ],
      ),
    );
    if (confirmed != true) return;
    final prefs = await SharedPreferences.getInstance();
    final now = DateTime.now().millisecondsSinceEpoch;
    for (final id in ids) {
      await prefs.setInt(_hiddenKey(id), now);
      await prefs.setInt(_cutoffKey(id), now);
      _hiddenAt[id] = now;
      _cutoffs[id] = now;
    }
    if (!mounted) return;
    setState(() { _conversations.removeWhere((row) => ids.contains(row['id']?.toString())); _selected.clear(); });
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('گفتگوها فقط از حساب شما حذف شدند.')));
  }

  Future<void> _toggleMuteSelected() async {
    if (_selected.isEmpty) return;
    final prefs = await SharedPreferences.getInstance();
    final mute = !_selected.every(_muted.contains);
    for (final id in _selected) {
      if (mute) { _muted.add(id); await prefs.setBool(_mutedKey(id), true); }
      else { _muted.remove(id); await prefs.remove(_mutedKey(id)); }
    }
    if (!mounted) return;
    setState(() => _selected.clear());
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(mute ? 'گفتگوها بی‌صدا شدند.' : 'صدای گفتگوها فعال شد.')));
  }

  Future<void> _createPrivateChat() async {
    final selected = await showDialog<Map<String, dynamic>>(context: context, builder: (_) => const _UserSearchDialog());
    if (selected == null) return;
    final userId = selected['id']?.toString();
    if (userId == null || userId.isEmpty) return;
    try {
      final result = await Api.request('/api/v1/conversations', method: 'POST', data: {'type': 'private', 'member_ids': <String>[userId]});
      final conversationId = (result['conversation_id'] ?? result['id'])?.toString();
      if (conversationId != null && conversationId.isNotEmpty) {
        final prefs = await SharedPreferences.getInstance();
        await prefs.remove(_hiddenKey(conversationId));
      }
      await _load();
    } catch (e) { if (mounted) setState(() => _error = e.toString().replaceFirst('Exception: ', '')); }
  }

  Future<void> _createGroupChat() async {
    final members = await showDialog<List<Map<String, dynamic>>>(
      context: context,
      builder: (_) => const _GroupUserSearchDialog(),
    );
    if (members == null || members.isEmpty) return;
    final titleController = TextEditingController();
    final title = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: panel,
        title: const Text('نام گروه'),
        content: TextField(controller: titleController, maxLength: 80, autofocus: true, decoration: const InputDecoration(hintText: 'نام گروه')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('انصراف')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, titleController.text.trim()), child: const Text('ساخت گروه')),
        ],
      ),
    );
    titleController.dispose();
    if (title == null || title.trim().isEmpty) return;
    try {
      await Api.request('/api/v1/conversations', method: 'POST', data: {
        'type': 'group',
        'title': title.trim(),
        'member_ids': members.map((m) => m['id'].toString()).toList(),
      });
      await _load();
    } catch (e) {
      if (mounted) setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
    }
  }

  Future<void> _logout() async {
    try { await Api.request('/api/v1/auth/logout', method: 'POST'); } catch (_) {}
    await _secureStorage.delete(key: 'vega_access_token');
    await _secureStorage.delete(key: 'vega_user_id');
    Api.token = null; Api.currentUserId = null;
    if (!mounted) return;
    Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const AuthPage()), (_) => false);
  }

  @override
  void dispose() {
    _homePollTimer?.cancel();
    _holdTimer?.cancel();
    _search.dispose();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final query = _search.text.trim().toLowerCase();
    final filtered = _conversations.where((item) {
      final title = (item['title'] ?? item['display_name'] ?? '').toString().toLowerCase();
      final last = (item['last_message'] ?? '').toString().toLowerCase();
      final matchesSearch = query.isEmpty || title.contains(query) || last.contains(query);
      final type = item['type']?.toString() ?? 'private';
      final matchesCategory = _category == 'همه' ||
          (_category == 'گفتگوها' && type == 'private') ||
          (_category == 'گروه‌ها' && type == 'group') ||
          (_category == 'کانال‌ها' && type == 'channel');
      return matchesSearch && matchesCategory;
    }).toList();
    return Scaffold(
      backgroundColor: bg,
      body: SafeArea(
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 12, 18, 10),
            child: Row(children: [
              if (_selected.isEmpty)
                Image.asset('assets/images/vega_full_logo.jpg', height: 38, width: 118, fit: BoxFit.contain)
              else
                Text('${_selected.length} گفتگو انتخاب شد', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 17)),
              const Spacer(),
              if (_selected.isEmpty) ...[
                IconButton(onPressed: _createPrivateChat, icon: const Icon(Icons.person_add_alt_1_rounded, color: cyan), tooltip: 'گفتگوی جدید'),
                IconButton(onPressed: _createGroupChat, icon: const Icon(Icons.group_add_rounded, color: cyan), tooltip: 'گروه گفت‌وگو'),
                IconButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => VegaCommunityPage(baseUrl: apiBaseUrl, tokenProvider: () async => Api.token))), icon: const Icon(Icons.groups_rounded, color: cyan), tooltip: 'گروه‌ها و کانال‌ها'),
                IconButton(onPressed: _logout, icon: const Icon(Icons.logout_rounded, color: Colors.white70), tooltip: 'خروج'),
              ] else ...[
                IconButton(onPressed: () => setState(() => _selected.clear()), icon: const Icon(Icons.close_rounded)),
                IconButton(onPressed: _toggleMuteSelected, icon: Icon(_selected.every(_muted.contains) ? Icons.volume_up_rounded : Icons.volume_off_rounded)),
                IconButton(onPressed: _deleteSelected, icon: const Icon(Icons.delete_outline_rounded, color: Colors.redAccent)),
              ],
            ]),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: TextField(
              controller: _search,
              onChanged: (_) => setState(() {}),
              decoration: InputDecoration(
                hintText: 'جست‌وجو…', prefixIcon: const Icon(Icons.search_rounded, color: purple),
                filled: true, fillColor: const Color(0xFF1B1737), contentPadding: const EdgeInsets.symmetric(vertical: 13),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
              ),
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(height: 44, child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            children: ['همه', 'گفتگوها', 'گروه‌ها', 'کانال‌ها'].map((label) {
              final active = _category == label;
              return Padding(padding: const EdgeInsets.only(left: 9), child: ChoiceChip(
                label: Text(label), selected: active, onSelected: (_) => setState(() => _category = label),
                selectedColor: purple.withOpacity(.28), backgroundColor: const Color(0xFF14152B),
                labelStyle: TextStyle(color: active ? Colors.white : const Color(0xFFB8A6E8), fontWeight: FontWeight.w600),
                side: BorderSide(color: active ? purple : const Color(0xFF282044)),
              ));
            }).toList(),
          )),
          const SizedBox(height: 5),
          Expanded(child: _loading
            ? const Center(child: CircularProgressIndicator(color: purple))
            : _error != null
              ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [Text(_error!, textAlign: TextAlign.center), const SizedBox(height: 12), FilledButton(onPressed: _load, child: const Text('تلاش دوباره'))])))
              : filtered.isEmpty
                ? Center(child: Text(query.isNotEmpty ? 'گفتگویی پیدا نشد' : 'هنوز گفتگویی ندارید', style: const TextStyle(color: Colors.white60)))
                : RefreshIndicator(color: purple, onRefresh: _load, child: ListView.separated(
                    padding: const EdgeInsets.only(top: 4, bottom: 12), itemCount: filtered.length,
                    separatorBuilder: (_, __) => const Divider(height: 1, indent: 78, color: Color(0x332D2850)),
                    itemBuilder: (context, index) {
                      final item = filtered[index];
                      final title = (item['title'] ?? item['display_name'] ?? 'گفتگو').toString().trim();
                      final last = (item['last_message'] ?? item['lastMessage'] ?? 'برای شروع گفتگو پیام بفرستید').toString();
                      final id = item['id']?.toString() ?? '';
                      final rawLastAt = item['last_message_at'] ?? item['lastMessageAt'];
                      final parsedLastAt = DateTime.tryParse(rawLastAt?.toString() ?? '')?.toLocal();
                      final displayTime = parsedLastAt == null
                          ? (item['time']?.toString() ?? '')
                          : '${parsedLastAt.hour.toString().padLeft(2, '0')}:${parsedLastAt.minute.toString().padLeft(2, '0')}';
                      final lastSeenRaw = item['peer_last_seen_at'] ?? item['peerLastSeenAt'];
                      final lastSeen = DateTime.tryParse(lastSeenRaw?.toString() ?? '');
                      final isOnline = lastSeen != null && DateTime.now().toUtc().difference(lastSeen.toUtc()).inMinutes < 2;
                      final isSelected = _selected.contains(id);
                      final initial = title.isNotEmpty ? title.characters.first.toUpperCase() : 'V';
                      return GestureDetector(
                        onTapDown: id.isEmpty ? null : (_) {
                          _holdTimer?.cancel(); _holdingId = id; _longPressActivated = false;
                          _holdTimer = Timer(const Duration(milliseconds: 650), () {
                            if (!mounted || _holdingId != id) return;
                            _longPressActivated = true; setState(() => _selected.add(id));
                          });
                        },
                        onTapUp: (_) => _holdTimer?.cancel(),
                        onTapCancel: () { _holdTimer?.cancel(); _holdingId = null; },
                        child: InkWell(
                          onTap: id.isEmpty ? null : () {
                            if (_longPressActivated && _holdingId == id) { _longPressActivated = false; _holdingId = null; return; }
                            _holdingId = null; _openOrSelect(item);
                          },
                          child: Container(
                            color: isSelected ? purple.withOpacity(.16) : Colors.transparent,
                            padding: const EdgeInsets.symmetric(horizontal: 17, vertical: 12),
                            child: Row(children: [
                              Stack(alignment: Alignment.bottomRight, children: [
                                Container(width: 58, height: 58, decoration: BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [purple.withOpacity(.75), const Color(0xFF32236B)]), border: Border.all(color: const Color(0xFFB69CFF), width: 1.2)), child: Center(child: Text(initial, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.bold, color: Colors.white)))),
                                Positioned(right: 1, bottom: 1, child: Container(width: 13, height: 13, decoration: BoxDecoration(color: isOnline ? cyan : const Color(0xFF687087), shape: BoxShape.circle, border: Border.all(color: bg, width: 2)))),
                              ]),
                              const SizedBox(width: 13),
                              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Row(children: [Expanded(child: Text(title.isEmpty ? 'گفتگو' : title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: Colors.white))), Text(displayTime, style: const TextStyle(fontSize: 11, color: Color(0xFFAA91E8))) ]),
                                const SizedBox(height: 5),
                                Text(last, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13, color: Color(0xFFB8A9D8))),
                              ])),
                              if (_muted.contains(id)) const Padding(padding: EdgeInsets.only(left: 5), child: Icon(Icons.volume_off_rounded, size: 17, color: Colors.white54)),
                              if (isSelected) const Padding(padding: EdgeInsets.only(left: 6), child: Icon(Icons.check_circle_rounded, color: cyan)),
                            ]),
                          ),
                        ),
                      );
                    },
                  )),
          ),
          Container(
            decoration: const BoxDecoration(color: Color(0xFF0D1022), border: Border(top: BorderSide(color: Color(0x332D2850)))),
            padding: const EdgeInsets.fromLTRB(8, 7, 8, 4),
            child: SafeArea(top: false, child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
              _bottomNav(Icons.person_rounded, 'پروفایل', false, () => Navigator.push(context, MaterialPageRoute(builder: (_) => VegaProfilePage(baseUrl: apiBaseUrl, tokenProvider: () async => Api.token)))),
              _bottomNav(Icons.settings_rounded, 'تنظیمات', false, () => Navigator.push(context, MaterialPageRoute(builder: (_) => VegaSettingsPage(baseUrl: apiBaseUrl, tokenProvider: () async => Api.token)))),
              _bottomNav(Icons.chat_bubble_rounded, 'گفتگوها', true, () {}),
              _bottomNav(Icons.contacts_rounded, 'مخاطبین', false, _createPrivateChat),
            ])),
          ),
        ]),
      ),
    );
  }

  Widget _bottomNav(IconData icon, String label, bool active, VoidCallback onTap) => InkWell(
    borderRadius: BorderRadius.circular(14),
    onTap: onTap,
    child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, color: active ? purple : const Color(0xFF82769F), size: 22),
        const SizedBox(height: 3), Text(label, style: TextStyle(fontSize: 10, color: active ? purple : const Color(0xFF82769F), fontWeight: active ? FontWeight.bold : FontWeight.normal)),
      ]),
    ),
  );
}

class ChatPage extends StatefulWidget {
  final String id;
  final String title;
  final String type;
  final int? historyCutoff;
  const ChatPage({super.key, required this.id, required this.title, this.type = 'private', this.historyCutoff});
  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> with WidgetsBindingObserver {
  final _input = TextEditingController();
  final _scroll = ScrollController();
  List<Map<String, dynamic>> _messages = [];
  String? _error;
  bool _loading = true;
  bool _sending = false;
  bool _fetching = false;
  bool _reloadRequested = false;
  Timer? _pollTimer;
  int _pollFailures = 0;
  DateTime _lastChatActivity = DateTime.now();
  int _lastMarkedReadMillis = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
    _startPolling();
  }

  void _startPolling() {
    _pollTimer?.cancel();
    _scheduleNextPoll(const Duration(seconds: 4));
  }

  void _scheduleNextPoll(Duration delay) {
    _pollTimer?.cancel();
    if (!mounted || WidgetsBinding.instance.lifecycleState != AppLifecycleState.resumed) {
      return;
    }
    _pollTimer = Timer(delay, () async {
      if (!mounted || WidgetsBinding.instance.lifecycleState != AppLifecycleState.resumed) {
        return;
      }
      await _load(silent: true);
      if (!mounted) return;
      _scheduleNextPoll(const Duration(seconds: 4));
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _load(silent: true);
      _startPolling();
    } else {
      _pollTimer?.cancel();
      _pollTimer = null;
    }
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    _input.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _load({bool silent = false}) async {
    if (_fetching) { _reloadRequested = true; return; }
    _fetching = true;
    try {
      final result = await Api.request('/api/v1/conversations/${widget.id}/messages');
      final rawRows = result['messages'] ?? result['items'] ?? result['data'];
      final rows = (rawRows as List? ?? const [])
          .whereType<Map>()
          .map((row) => Map<String, dynamic>.from(row))
          .where((row) {
            if (widget.historyCutoff == null) return true;
            final timestamp = _messageTime(row);
            final millis = timestamp > 1000000000000 ? timestamp : timestamp * 1000;
            return millis >= widget.historyCutoff!;
          })
          .toList();
      rows.sort((a, b) => _messageTime(a).compareTo(_messageTime(b)));
      if (mounted) {
        final changed = jsonEncode(rows) != jsonEncode(_messages);
        setState(() {
          _messages = rows;
          _error = null;
          _loading = false;
        });
        _pollFailures = 0;
        if (changed) _lastChatActivity = DateTime.now();
        // Mark incoming messages as read only while this conversation is open.
        final myId = Api.currentUserId;
        if (myId != null) {
          var newestIncoming = 0;
          for (final row in rows) {
            if (_senderId(row) == myId) continue;
            final raw = _messageTime(row);
            final millis = raw > 1000000000000 ? raw : raw * 1000;
            if (millis > newestIncoming) newestIncoming = millis;
          }
          if (newestIncoming > _lastMarkedReadMillis) {
            try {
              await Api.request('/api/v1/conversations/${widget.id}/read',
                method: 'POST',
                data: {'through': DateTime.fromMillisecondsSinceEpoch(newestIncoming, isUtc: true).toIso8601String()},
              );
              _lastMarkedReadMillis = newestIncoming;
            } catch (_) {
              // A later poll retries the read receipt if the network is unavailable.
            }
          }
        }
      }
    } catch (e) {
      _pollFailures = (_pollFailures + 1).clamp(1, 4).toInt();
      if (mounted && !silent) {
        setState(() {
          _error = e.toString().replaceFirst('Exception: ', '');
          _loading = false;
        });
      }
    } finally {
      _fetching = false;
      if (_reloadRequested && mounted) {
        _reloadRequested = false;
        scheduleMicrotask(() => _load(silent: true));
      }
    }
  }

  int _messageTime(Map<String, dynamic> message) {
    final value = message['created_at'] ?? message['createdAt'] ?? message['timestamp'];
    if (value is num) return value.toInt();
    if (value is String) {
      final numeric = int.tryParse(value);
      if (numeric != null) return numeric;
      return DateTime.tryParse(value)?.millisecondsSinceEpoch ?? 0;
    }
    return 0;
  }

  String _formatMessageTime(Map<String, dynamic> message) {
    final value = _messageTime(message);
    if (value <= 0) return '';
    final millis = value > 1000000000000 ? value : value * 1000;
    final date = DateTime.fromMillisecondsSinceEpoch(millis).toLocal();
    return '${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}';
  }

  String _senderId(Map<String, dynamic> message) =>
      (message['sender_id'] ?? message['senderId'] ?? message['user_id'] ??
              message['userId'] ?? message['author_id'] ?? '')
          .toString();

  Future<void> _showMessageActions(Map<String, dynamic> message, bool isMine) async {
    final action = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: panel,
      builder: (sheetContext) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(leading: const Icon(Icons.copy_rounded), title: const Text('کپی پیام'), onTap: () => Navigator.pop(sheetContext, 'copy')),
          if (isMine) ListTile(leading: const Icon(Icons.edit_rounded), title: const Text('ویرایش پیام'), onTap: () => Navigator.pop(sheetContext, 'edit')),
          if (isMine) ListTile(leading: const Icon(Icons.delete_outline_rounded, color: Colors.redAccent), title: const Text('حذف پیام'), onTap: () => Navigator.pop(sheetContext, 'delete')),
          ListTile(leading: const Icon(Icons.forward_rounded), title: const Text('هدایت پیام'), onTap: () => Navigator.pop(sheetContext, 'forward')),
        ]),
      ),
    );
    if (!mounted || action == null) return;
    final body = message['body']?.toString() ?? '';
    final messageId = message['id']?.toString() ?? '';
    try {
      if (action == 'copy') {
        await Clipboard.setData(ClipboardData(text: body));
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('پیام کپی شد.')));
      } else if (action == 'edit' && isMine && messageId.isNotEmpty) {
        final controller = TextEditingController(text: body);
        final edited = await showDialog<String>(
          context: context,
          builder: (dialogContext) => AlertDialog(
            backgroundColor: panel,
            title: const Text('ویرایش پیام'),
            content: TextField(controller: controller, autofocus: true, maxLines: 5, decoration: const InputDecoration(hintText: 'متن پیام')),
            actions: [
              TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('انصراف')),
              FilledButton(onPressed: () => Navigator.pop(dialogContext, controller.text.trim()), child: const Text('ذخیره')),
            ],
          ),
        );
        controller.dispose();
        if (edited != null && edited.isNotEmpty) {
          await Api.request('/api/v1/messages/$messageId', method: 'PATCH', data: {'body': edited});
          await _load();
        }
      } else if (action == 'delete' && isMine && messageId.isNotEmpty) {
        final confirm = await showDialog<bool>(context: context, builder: (dialogContext) => AlertDialog(
          backgroundColor: panel,
          title: const Text('حذف پیام؟'),
          content: const Text('این پیام برای اعضای گفتگو حذف می‌شود.'),
          actions: [TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('انصراف')), FilledButton.tonal(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('حذف'))],
        ));
        if (confirm == true) {
          await Api.request('/api/v1/messages/$messageId', method: 'DELETE');
          await _load();
        }
      } else if (action == 'forward') {
        await _forwardMessage(body);
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('عملیات انجام نشد: ${e.toString().replaceFirst('Exception: ', '')}')));
    }
  }

  Future<void> _forwardMessage(String body) async {
    final result = await Api.request('/api/v1/conversations');
    final rows = (result['items'] ?? result['conversations'] ?? const []) as List? ?? const [];
    final targets = rows.whereType<Map>().map((row) => Map<String, dynamic>.from(row))
        .where((row) => row['id']?.toString() != widget.id).toList();
    if (!mounted || targets.isEmpty) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('گفتگوی دیگری برای هدایت پیام پیدا نشد.')));
      return;
    }
    final target = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (dialogContext) => SimpleDialog(
        backgroundColor: panel,
        title: const Text('هدایت به گفتگو'),
        children: targets.map((row) => SimpleDialogOption(
          onPressed: () => Navigator.pop(dialogContext, row),
          child: Text((row['title']?.toString().trim().isNotEmpty ?? false) ? row['title'].toString() : 'گفتگو'),
        )).toList(),
      ),
    );
    final id = target?['id']?.toString();
    if (id == null || id.isEmpty) return;
    await Api.request('/api/v1/conversations/$id/messages', method: 'POST', data: {'body': body, 'content_type': 'text'});
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('پیام هدایت شد.')));
  }

  Future<void> _send() async {
    final value = _input.text.trim();
    if (value.isEmpty || _sending) return;
    setState(() => _sending = true);
    try {
      await Api.request(
        '/api/v1/conversations/${widget.id}/messages',
        method: 'POST',
        data: {'body': value, 'content_type': 'text'},
      );
      _input.clear();
      _lastChatActivity = DateTime.now();
      _pollFailures = 0;
      await _load();
      _scheduleNextPoll(const Duration(seconds: 4));
      if (_scroll.hasClients) {
        await _scroll.animateTo(
          _scroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 180),
          curve: Curves.easeOut,
        );
      }
    } catch (e) {
      if (mounted) {
        setState(() => _error = 'ارسال پیام تأیید نشد؛ متن پیام باقی ماند. اتصال را بررسی کن و دوباره تلاش کن.\n${e.toString().replaceFirst('Exception: ', '')}');
      }
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          leading: IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_back_rounded)),
          titleSpacing: 0,
          title: Row(children: [
            Container(width: 38, height: 38, decoration: const BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [purple, Color(0xFF38216E)])), child: Center(child: Text((widget.title.isNotEmpty ? widget.title.characters.first : 'V').toUpperCase(), style: const TextStyle(fontWeight: FontWeight.bold)))),
            const SizedBox(width: 10),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
              Text(widget.title.isEmpty ? 'گفتگوی VEGA' : widget.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
              Text(widget.type == 'group' ? 'گفتگوی گروهی' : 'گفتگوی خصوصی', style: const TextStyle(fontSize: 11, color: cyan)),
            ])),
          ]),
          actions: [IconButton(onPressed: () => _load(), icon: const Icon(Icons.refresh_rounded))],
        ),
        body: Column(
          children: [
            if (_error != null)
              Padding(
                padding: const EdgeInsets.all(8),
                child: Text(_error!, style: const TextStyle(color: Colors.redAccent)),
              ),
            Expanded(
              child: Container(
                decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF111027), bg])),
                child: _loading
                  ? const Center(child: CircularProgressIndicator(color: purple))
                  : ListView.builder(
                      controller: _scroll,
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 16),
                      itemCount: _messages.length,
                      itemBuilder: (context, index) {
                        final message = _messages[index];
                        final body = message['body']?.toString() ?? '';
                        final senderId = _senderId(message);
                        final isMine = Api.currentUserId != null &&
                            senderId == Api.currentUserId;
                        return Align(
                          alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
                          child: InkWell(
                            borderRadius: BorderRadius.circular(17),
                            onTap: () => _showMessageActions(message, isMine),
                            child: Container(
                            constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .78),
                            margin: const EdgeInsets.symmetric(vertical: 5),
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                            decoration: BoxDecoration(
                              gradient: isMine ? const LinearGradient(colors: [Color(0xFF6421C9), Color(0xFF43118D)]) : null,
                              color: isMine ? null : const Color(0xFF25243F),
                              borderRadius: BorderRadius.only(topLeft: const Radius.circular(18), topRight: const Radius.circular(18), bottomLeft: Radius.circular(isMine ? 18 : 5), bottomRight: Radius.circular(isMine ? 5 : 18)),
                              border: Border.all(color: isMine ? const Color(0x665E35B1) : const Color(0x332E2A4D)),
                            ),
                            child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                              Align(alignment: Alignment.centerLeft, child: Text(body, style: const TextStyle(color: Colors.white, fontSize: 15, height: 1.35))),
                              const SizedBox(height: 4),
                              Row(mainAxisSize: MainAxisSize.min, children: [
                                if (message['edited_at'] != null || message['editedAt'] != null) const Padding(padding: EdgeInsets.only(right: 5), child: Text('ویرایش‌شده', style: TextStyle(fontSize: 9, color: Colors.white60))),
                                Text(_formatMessageTime(message), style: const TextStyle(fontSize: 10, color: Colors.white60)),
                                if (isMine) Padding(
                                  padding: const EdgeInsets.only(left: 4),
                                  child: Icon(
                                    Icons.done_all_rounded,
                                    size: 13,
                                    color: (message['read_by_recipient'] == true || message['read_by_recipient'] == 1 || message['readByRecipient'] == true)
                                      ? cyan : Colors.white60,
                                  ),
                                ),
                              ]),
                            ]),
                            ),
                          ),
                        );
                      },
                    ),
              ),
            ),
            SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(10, 8, 10, 10),
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _input,
                        minLines: 1,
                        maxLines: 5,
                        textInputAction: TextInputAction.newline,
                        decoration: InputDecoration(hintText: 'پیامی بنویسید…', filled: true, fillColor: const Color(0xFF17152D), contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12), border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: const BorderSide(color: Color(0x553D2C68)))),
                      ),
                    ),
                    const SizedBox(width: 5),
                    IconButton(onPressed: () {}, icon: const Icon(Icons.emoji_emotions_outlined, color: Color(0xFFB49AF4))),
                    const SizedBox(width: 2),
                    IconButton(
                      onPressed: _sending ? null : _send,
                      icon: _sending
                          ? const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Icon(Icons.send_rounded, color: cyan),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      );
}

class _UserSearchDialog extends StatefulWidget {
  const _UserSearchDialog();

  @override
  State<_UserSearchDialog> createState() => _UserSearchDialogState();
}

class _UserSearchDialogState extends State<_UserSearchDialog> {
  final _query = TextEditingController();
  List<Map<String, dynamic>> _users = [];
  bool _loading = false;
  String? _error;

  @override
  void dispose() {
    _query.dispose();
    super.dispose();
  }

  Future<void> _search() async {
    final query = _query.text.trim();
    if (query.length < 2) {
      setState(() {
        _users = [];
        _error = 'حداقل دو نویسه وارد کن.';
      });
      return;
    }
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final result = await Api.request(
        '/api/v1/users/search?q=${Uri.encodeQueryComponent(query)}',
      );
      final users = (result['users'] as List? ?? const [])
          .whereType<Map>()
          .map((row) => Map<String, dynamic>.from(row))
          .toList();
      if (mounted) setState(() => _users = users);
    } catch (e) {
      if (mounted) setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
        title: const Text('گفتگوی خصوصی جدید'),
        content: SizedBox(
          width: 420,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: _query,
                autofocus: true,
                textCapitalization: TextCapitalization.none,
                decoration: InputDecoration(
                  labelText: 'نام کاربری یا نام نمایشی',
                  suffixIcon: IconButton(
                    onPressed: _loading ? null : _search,
                    icon: const Icon(Icons.search),
                  ),
                ),
                onSubmitted: (_) => _search(),
              ),
              const SizedBox(height: 10),
              if (_loading) const LinearProgressIndicator(),
              if (_error != null)
                Padding(
                  padding: const EdgeInsets.all(8),
                  child: Text(_error!, textAlign: TextAlign.center),
                ),
              if (!_loading && _users.isEmpty && _error == null)
                const Padding(
                  padding: EdgeInsets.all(12),
                  child: Text('برای جست‌وجو نام کاربری را وارد کن.'),
                ),
              if (_users.isNotEmpty)
                SizedBox(
                  height: 220,
                  child: ListView.builder(
                    shrinkWrap: true,
                    itemCount: _users.length,
                    itemBuilder: (context, index) {
                      final user = _users[index];
                      final displayName = user['display_name']?.toString() ?? '';
                      final username = user['username']?.toString() ?? '';
                      return ListTile(
                        leading: const CircleAvatar(child: Icon(Icons.person_outline)),
                        title: Text(displayName.isEmpty ? username : displayName),
                        subtitle: Text('@$username'),
                        onTap: () => Navigator.pop(context, user),
                      );
                    },
                  ),
                ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('بستن'),
          ),
        ],
      );
}


class _GroupUserSearchDialog extends StatefulWidget {
  const _GroupUserSearchDialog();
  @override
  State<_GroupUserSearchDialog> createState() => _GroupUserSearchDialogState();
}

class _GroupUserSearchDialogState extends State<_GroupUserSearchDialog> {
  final _query = TextEditingController();
  final Map<String, Map<String, dynamic>> _selected = {};
  List<Map<String, dynamic>> _users = [];
  bool _loading = false;
  String? _error;

  Future<void> _search() async {
    final query = _query.text.trim();
    if (query.isEmpty) return;
    setState(() { _loading = true; _error = null; });
    try {
      final result = await Api.request('/api/v1/users/search?q=${Uri.encodeQueryComponent(query)}');
      final rows = (result['users'] as List? ?? const [])
          .whereType<Map>()
          .map((row) => Map<String, dynamic>.from(row))
          .where((row) => row['id']?.toString() != Api.currentUserId)
          .toList();
      if (mounted) setState(() => _users = rows);
    } catch (e) {
      if (mounted) setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  void dispose() { _query.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => AlertDialog(
    backgroundColor: panel,
    title: Text('انتخاب اعضای گروه (${_selected.length})'),
    content: SizedBox(
      width: 440,
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(
          controller: _query,
          autofocus: true,
          decoration: InputDecoration(
            hintText: 'جست‌وجوی نام کاربری',
            suffixIcon: IconButton(onPressed: _loading ? null : _search, icon: const Icon(Icons.search)),
          ),
          onSubmitted: (_) => _search(),
        ),
        const SizedBox(height: 8),
        if (_loading) const LinearProgressIndicator(),
        if (_error != null) Text(_error!, style: const TextStyle(color: Colors.redAccent)),
        SizedBox(
          height: 280,
          child: ListView.builder(
            itemCount: _users.length,
            itemBuilder: (_, index) {
              final user = _users[index];
              final id = user['id']?.toString() ?? '';
              final name = user['display_name']?.toString().isNotEmpty == true
                  ? user['display_name'].toString()
                  : user['username']?.toString() ?? id;
              return CheckboxListTile(
                value: _selected.containsKey(id),
                title: Text(name),
                subtitle: Text('@${user['username'] ?? ''}'),
                onChanged: (checked) {
                  if (id.isEmpty) return;
                  setState(() {
                    if (checked == true && _selected.length < 50) _selected[id] = user;
                    else _selected.remove(id);
                  });
                },
              );
            },
          ),
        ),
      ]),
    ),
    actions: [
      TextButton(onPressed: () => Navigator.pop(context), child: const Text('انصراف')),
      FilledButton(
        onPressed: _selected.isEmpty ? null : () => Navigator.pop(context, _selected.values.toList()),
        child: const Text('ادامه'),
      ),
    ],
  );
}
