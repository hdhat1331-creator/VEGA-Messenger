import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:cryptography/cryptography.dart';
import 'package:path/path.dart' as p;

/// Chunked file encryption for VEGA.
///
/// The encrypted output can be relayed/stored by the server, but the raw
/// file key must remain on the sender/recipient devices.
class VegaMediaCrypto {
  VegaMediaCrypto({Random? random})
      : _random = random ?? Random.secure();

  final Random _random;
  final AesGcm _aead = AesGcm.with256bits();

  static const int defaultChunkSize = 256 * 1024;
  static const String format = 'VEGA-MEDIA-1';

  /// Encrypts [inputFile] into a separate encrypted file.
  ///
  /// Returns the encrypted file, a manifest, and a base64 file key.
  /// The caller must wrap the file key for each recipient before sending.
  Future<VegaEncryptedMedia> encryptFile({
    required File inputFile,
    required Directory outputDirectory,
    int chunkSize = defaultChunkSize,
  }) async {
    if (chunkSize < 16 * 1024 || chunkSize > 1024 * 1024) {
      throw ArgumentError('chunkSize must be between 16 KiB and 1 MiB.');
    }
    if (!await inputFile.exists()) {
      throw FileSystemException('Input file does not exist.', inputFile.path);
    }

    await outputDirectory.create(recursive: true);
    final inputLength = await inputFile.length();
    final fileKey = _randomBytes(32);
    final noncePrefix = _randomBytes(8);
    final output = File(
      p.join(outputDirectory.path, '${_randomId()}.vegaenc'),
    );

    final sink = output.openWrite();
    final input = inputFile.openRead();
    var index = 0;
    var totalPlain = 0;

    try {
      var pending = <int>[];
      await for (final bytes in input) {
        pending.addAll(bytes);
        while (pending.length >= chunkSize) {
          final chunk = pending.sublist(0, chunkSize);
          pending = pending.sublist(chunkSize);
          final encrypted = await _encryptChunk(
            chunk,
            fileKey,
            noncePrefix,
            index,
          );
          sink.add(encrypted);
          totalPlain += chunk.length;
          index++;
        }
      }

      if (pending.isNotEmpty || inputLength == 0) {
        final encrypted = await _encryptChunk(
          pending,
          fileKey,
          noncePrefix,
          index,
        );
        sink.add(encrypted);
        totalPlain += pending.length;
        index++;
      }
    } catch (_) {
      await sink.close();
      if (await output.exists()) await output.delete();
      rethrow;
    }
    await sink.close();

    final manifest = <String, dynamic>{
      'format': format,
      'version': 1,
      'originalName': p.basename(inputFile.path),
      'plainSize': inputLength,
      'chunkSize': chunkSize,
      'chunkCount': index,
      'noncePrefix': base64Encode(noncePrefix),
      'tagLength': 16,
      'cipher': 'AES-256-GCM',
    };

    return VegaEncryptedMedia(
      encryptedFile: output,
      manifest: manifest,
      fileKeyBase64: base64Encode(fileKey),
      encryptedSize: await output.length(),
    );
  }

  /// Decrypts an encrypted media file to [outputFile].
  Future<File> decryptFile({
    required File encryptedFile,
    required File outputFile,
    required Map<String, dynamic> manifest,
    required String fileKeyBase64,
  }) async {
    if (manifest['format'] != format || manifest['version'] != 1) {
      throw FormatException('Unsupported VEGA media format.');
    }

    final key = base64Decode(fileKeyBase64);
    final noncePrefix = base64Decode(manifest['noncePrefix'] as String);
    final chunkSize = manifest['chunkSize'] as int;
    final chunkCount = manifest['chunkCount'] as int;
    final plainSize = manifest['plainSize'] as int;

    if (key.length != 32 ||
        noncePrefix.length != 8 ||
        chunkSize < 1 ||
        chunkCount < 1 ||
        plainSize < 0) {
      throw FormatException('Invalid VEGA media manifest.');
    }

    await outputFile.parent.create(recursive: true);
    final raf = await encryptedFile.open();
    final out = await outputFile.open(mode: FileMode.write);
    var remaining = plainSize;

    try {
      for (var index = 0; index < chunkCount; index++) {
        final expectedPlainLength =
            remaining > chunkSize ? chunkSize : remaining;
        final encryptedLength = expectedPlainLength + 16;
        final encryptedChunk = await raf.read(encryptedLength);
        if (encryptedChunk.length != encryptedLength) {
          throw FormatException('Encrypted media is truncated.');
        }

        final clear = await _decryptChunk(
          encryptedChunk,
          key,
          noncePrefix,
          index,
        );
        if (clear.length != expectedPlainLength) {
          throw FormatException('Media chunk length mismatch.');
        }
        await out.writeFrom(clear);
        remaining -= clear.length;
      }

      if (remaining != 0 || await raf.length() != await raf.position()) {
        throw FormatException('Media size or trailing data mismatch.');
      }
    } catch (_) {
      await out.close();
      await raf.close();
      if (await outputFile.exists()) await outputFile.delete();
      rethrow;
    }

    await out.close();
    await raf.close();
    return outputFile;
  }

  Future<List<int>> _encryptChunk(
    List<int> clear,
    List<int> keyBytes,
    List<int> noncePrefix,
    int index,
  ) async {
    final nonce = _nonce(noncePrefix, index);
    final aad = utf8.encode('$format|$index|${clear.length}');
    final box = await _aead.encrypt(
      clear,
      secretKey: SecretKey(keyBytes),
      nonce: nonce,
      aad: aad,
    );
    return <int>[...box.cipherText, ...box.mac.bytes];
  }

  Future<List<int>> _decryptChunk(
    List<int> encrypted,
    List<int> keyBytes,
    List<int> noncePrefix,
    int index,
  ) async {
    if (encrypted.length < 16) {
      throw FormatException('Encrypted chunk is too short.');
    }
    final cipherText = encrypted.sublist(0, encrypted.length - 16);
    final mac = encrypted.sublist(encrypted.length - 16);
    final nonce = _nonce(noncePrefix, index);
    final aad = utf8.encode('$format|$index|${cipherText.length}');
    return _aead.decrypt(
      SecretBox(cipherText, nonce: nonce, mac: Mac(mac)),
      secretKey: SecretKey(keyBytes),
      aad: aad,
    );
  }

  List<int> _nonce(List<int> prefix, int index) {
    if (index < 0 || index > 0xFFFFFFFF) {
      throw RangeError('Too many media chunks.');
    }
    return <int>[
      ...prefix,
      (index >> 24) & 0xff,
      (index >> 16) & 0xff,
      (index >> 8) & 0xff,
      index & 0xff,
    ];
  }

  List<int> _randomBytes(int length) =>
      List<int>.generate(length, (_) => _random.nextInt(256));

  String _randomId() => base64UrlEncode(_randomBytes(18)).replaceAll('=', '');
}

class VegaEncryptedMedia {
  const VegaEncryptedMedia({
    required this.encryptedFile,
    required this.manifest,
    required this.fileKeyBase64,
    required this.encryptedSize,
  });

  final File encryptedFile;
  final Map<String, dynamic> manifest;
  final String fileKeyBase64;
  final int encryptedSize;

  Map<String, dynamic> toTransferDescriptor({
    required Map<String, dynamic> wrappedFileKey,
  }) =>
      <String, dynamic>{
        'manifest': manifest,
        'wrappedFileKey': wrappedFileKey,
        'encryptedSize': encryptedSize,
      };
}
