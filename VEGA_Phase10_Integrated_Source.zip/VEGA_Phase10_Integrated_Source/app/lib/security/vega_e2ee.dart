import 'dart:convert';
import 'dart:math';

import 'package:cryptography/cryptography.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// Minimal one-to-one E2EE building block for VEGA.
///
/// The server should only receive the JSON payload returned by
/// [encryptForRecipient], never the plaintext message.
class VegaE2EE {
  VegaE2EE({
    FlutterSecureStorage? secureStorage,
    Random? random,
  })  : _storage = secureStorage ?? const FlutterSecureStorage(),
        _random = random ?? Random.secure();

  static const _x25519SeedKey = 'vega_e2ee_x25519_seed_v1';

  final FlutterSecureStorage _storage;
  final Random _random;

  final _x25519 = X25519();
  final _hkdf = Hkdf(
    hmac: Hmac.sha256(),
    outputLength: 32,
  );
  final _aesGcm = AesGcm.with256bits();

  SimpleKeyPair? _identityKeyPair;
  String? _publicIdentityKeyBase64;

  String? get publicIdentityKeyBase64 => _publicIdentityKeyBase64;

  Future<void> initialize() async {
    final stored = await _storage.read(key: _x25519SeedKey);
    final seed = stored == null
        ? _randomBytes(32)
        : base64Decode(stored);

    if (seed.length != 32) {
      throw StateError('Stored VEGA identity seed is invalid.');
    }

    if (stored == null) {
      await _storage.write(
        key: _x25519SeedKey,
        value: base64Encode(seed),
      );
    }

    final pair = await _x25519.newKeyPairFromSeed(seed);
    final publicKey = await pair.extractPublicKey();

    _identityKeyPair = pair;
    _publicIdentityKeyBase64 = base64Encode(publicKey.bytes);
  }

  /// Encrypts UTF-8 text for one recipient using the sender's identity key.
  ///
  /// The recipient public key must be obtained from the authenticated
  /// VEGA key directory and verified by the user when required.
  Future<Map<String, dynamic>> encryptForRecipient({
    required String plaintext,
    required String recipientPublicKeyBase64,
    required String senderUserId,
    required String recipientUserId,
  }) async {
    final ownPair = _requireIdentityPair();
    final recipientBytes = base64Decode(recipientPublicKeyBase64);
    if (recipientBytes.length != 32) {
      throw ArgumentError('Recipient public key must be 32 bytes.');
    }

    final recipientPublicKey = SimplePublicKey(
      recipientBytes,
      type: KeyPairType.x25519,
    );

    final sharedSecret = await _x25519.sharedSecretKey(
      keyPair: ownPair,
      remotePublicKey: recipientPublicKey,
    );

    final salt = _randomBytes(32);
    final messageKey = await _hkdf.deriveKey(
      secretKey: sharedSecret,
      nonce: salt,
      info: utf8.encode('VEGA-E2EE-1|$senderUserId|$recipientUserId'),
    );

    final nonce = _randomBytes(12);
    final aad = utf8.encode('VEGA-E2EE-1|$senderUserId|$recipientUserId');
    final box = await _aesGcm.encrypt(
      utf8.encode(plaintext),
      secretKey: messageKey,
      nonce: nonce,
      aad: aad,
    );

    final senderPublic = await ownPair.extractPublicKey();

    return <String, dynamic>{
      'version': 1,
      'algorithm': 'X25519-HKDF-SHA256-AES-256-GCM',
      'senderUserId': senderUserId,
      'recipientUserId': recipientUserId,
      'senderPublicKey': base64Encode(senderPublic.bytes),
      'salt': base64Encode(salt),
      'nonce': base64Encode(box.nonce),
      'cipherText': base64Encode(box.cipherText),
      'mac': base64Encode(box.mac.bytes),
    };
  }

  /// Decrypts a payload created by [encryptForRecipient].
  Future<String> decryptFromSender(
    Map<String, dynamic> payload, {
    required String expectedSenderUserId,
    required String currentUserId,
  }) async {
    if (payload['version'] != 1 ||
        payload['algorithm'] != 'X25519-HKDF-SHA256-AES-256-GCM') {
      throw FormatException('Unsupported VEGA encrypted payload.');
    }

    if (payload['senderUserId'] != expectedSenderUserId ||
        payload['recipientUserId'] != currentUserId) {
      throw FormatException('Encrypted payload identity mismatch.');
    }

    final ownPair = _requireIdentityPair();
    final senderBytes = base64Decode(payload['senderPublicKey'] as String);
    final salt = base64Decode(payload['salt'] as String);
    final nonce = base64Decode(payload['nonce'] as String);
    final cipherText = base64Decode(payload['cipherText'] as String);
    final mac = base64Decode(payload['mac'] as String);

    if (senderBytes.length != 32 || salt.length != 32 || nonce.length != 12) {
      throw FormatException('Malformed VEGA encrypted payload.');
    }

    final senderPublicKey = SimplePublicKey(
      senderBytes,
      type: KeyPairType.x25519,
    );

    final sharedSecret = await _x25519.sharedSecretKey(
      keyPair: ownPair,
      remotePublicKey: senderPublicKey,
    );

    final senderId = expectedSenderUserId;
    final recipientId = currentUserId;
    final messageKey = await _hkdf.deriveKey(
      secretKey: sharedSecret,
      nonce: salt,
      info: utf8.encode('VEGA-E2EE-1|$senderId|$recipientId'),
    );

    final aad = utf8.encode('VEGA-E2EE-1|$senderId|$recipientId');
    final secretBox = SecretBox(
      cipherText,
      nonce: nonce,
      mac: Mac(mac),
    );

    final clearBytes = await _aesGcm.decrypt(
      secretBox,
      secretKey: messageKey,
      aad: aad,
    );
    return utf8.decode(clearBytes);
  }

  SimpleKeyPair _requireIdentityPair() {
    final pair = _identityKeyPair;
    if (pair == null) {
      throw StateError('Call initialize() before using VEGA E2EE.');
    }
    return pair;
  }

  List<int> _randomBytes(int length) =>
      List<int>.generate(length, (_) => _random.nextInt(256));
}
