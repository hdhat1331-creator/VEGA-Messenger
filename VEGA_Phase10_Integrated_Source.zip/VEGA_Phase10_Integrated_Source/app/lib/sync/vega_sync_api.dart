import 'dart:convert';
import 'package:http/http.dart' as http;

/// API transport for VEGA sync. Authentication token is supplied by the app's
/// existing secure session store; this class never persists credentials.
class VegaSyncApi {
  VegaSyncApi({
    required this.baseUrl,
    required this.readAccessToken,
    http.Client? client,
  }) : _client = client ?? http.Client();

  final String baseUrl;
  final Future<String?> Function() readAccessToken;
  final http.Client _client;

  Future<Map<String, String>> _headers() async {
    final token = await readAccessToken();
    if (token == null || token.isEmpty) throw StateError('Not authenticated');
    return {
      'content-type': 'application/json',
      'authorization': 'Bearer $token',
    };
  }

  Future<Map<String, dynamic>> _request(
    String method,
    String path, {
    Map<String, dynamic>? body,
  }) async {
    final uri = Uri.parse('$baseUrl$path');
    final headers = await _headers();
    late http.Response response;
    switch (method) {
      case 'GET':
        response = await _client.get(uri, headers: headers);
        break;
      case 'POST':
        response = await _client.post(uri, headers: headers, body: jsonEncode(body));
        break;
      case 'PUT':
        response = await _client.put(uri, headers: headers, body: jsonEncode(body));
        break;
      case 'DELETE':
        response = await _client.delete(uri, headers: headers, body: jsonEncode(body));
        break;
      default:
        throw ArgumentError('Unsupported method');
    }
    final decoded = response.body.isEmpty
        ? <String, dynamic>{}
        : jsonDecode(response.body) as Map<String, dynamic>;
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw VegaSyncException(response.statusCode, decoded['error']?.toString() ?? 'request_failed');
    }
    return decoded;
  }

  Future<Map<String, dynamic>> enqueueEncryptedMessage({
    required String conversationId,
    required String recipientUserId,
    required String encryptedPayload,
    required String idempotencyKey,
  }) => _request('POST', '/api/v1/sync/queue', body: {
        'conversationId': conversationId,
        'recipientUserId': recipientUserId,
        'encryptedPayload': encryptedPayload,
        'idempotencyKey': idempotencyKey,
      });

  Future<List<Map<String, dynamic>>> getPending({int limit = 50}) async {
    final result = await _request('GET', '/api/v1/sync/pending?limit=$limit');
    return (result['items'] as List? ?? const [])
        .cast<Map<String, dynamic>>();
  }

  Future<int> acknowledge(List<String> messageIds) async {
    if (messageIds.isEmpty) return 0;
    final result = await _request('POST', '/api/v1/sync/ack',
        body: {'messageIds': messageIds});
    return (result['acknowledged'] as num? ?? 0).toInt();
  }

  Future<Map<String, dynamic>> getChanges({int after = 0, int limit = 100}) =>
      _request('GET', '/api/v1/sync/changes?after=$after&limit=$limit');

  Future<Map<String, dynamic>> getNotificationPreferences() =>
      _request('GET', '/api/v1/notifications/preferences');

  Future<void> updateNotificationPreferences({
    required bool directMessages,
    required bool groupMessages,
    required bool channelPosts,
    required bool soundEnabled,
  }) async {
    await _request('PUT', '/api/v1/notifications/preferences', body: {
      'directMessages': directMessages,
      'groupMessages': groupMessages,
      'channelPosts': channelPosts,
      'soundEnabled': soundEnabled,
    });
  }

  Future<void> registerPushDevice({
    required String platform,
    required String pushToken,
    String? deviceLabel,
  }) async {
    await _request('POST', '/api/v1/notifications/devices', body: {
      'platform': platform,
      'pushToken': pushToken,
      if (deviceLabel != null) 'deviceLabel': deviceLabel,
    });
  }

  Future<void> unregisterPushDevice(String pushToken) async {
    await _request('DELETE', '/api/v1/notifications/devices',
        body: {'pushToken': pushToken});
  }

  void close() => _client.close();
}

class VegaSyncException implements Exception {
  VegaSyncException(this.statusCode, this.code);
  final int statusCode;
  final String code;
  @override
  String toString() => 'VEGA sync error ($statusCode): $code';
}
