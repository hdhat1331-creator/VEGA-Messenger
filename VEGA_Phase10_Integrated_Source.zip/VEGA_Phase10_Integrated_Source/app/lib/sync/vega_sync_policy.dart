import 'dart:math';

/// Retry delay helper. The caller should retry only while the app is active,
/// and should stop after a bounded number of attempts or on authentication errors.
class VegaRetryPolicy {
  const VegaRetryPolicy({
    this.initialDelay = const Duration(seconds: 2),
    this.maximumDelay = const Duration(minutes: 2),
    this.maximumAttempts = 6,
  });

  final Duration initialDelay;
  final Duration maximumDelay;
  final int maximumAttempts;

  Duration delayForAttempt(int attempt, {Random? random}) {
    if (attempt < 0 || attempt >= maximumAttempts) {
      throw RangeError.range(attempt, 0, maximumAttempts - 1, 'attempt');
    }
    final multiplier = 1 << attempt;
    final rawMs = min(
      initialDelay.inMilliseconds * multiplier,
      maximumDelay.inMilliseconds,
    );
    // Small jitter prevents many clients retrying at the same instant.
    final jitter = (random ?? Random()).nextDouble() * 0.25 + 0.875;
    return Duration(milliseconds: (rawMs * jitter).round());
  }
}

/// Cursor value is persisted by the app's encrypted local store after all
/// events up to this ID have been applied successfully.
class VegaSyncCursor {
  const VegaSyncCursor(this.value);
  final int value;

  VegaSyncCursor advanceTo(int next) {
    if (next < value) throw StateError('Sync cursor cannot move backwards');
    return VegaSyncCursor(next);
  }
}
