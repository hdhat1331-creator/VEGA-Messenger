# اصلاحات سرور VEGA – Phase 10

این اصلاحیه برای مخزن فعلی `hdhat1331-creator/vega-server` نوشته شده است؛
**فایل‌های قدیمی `vega-server` داخل بسته Phase 9 را جایگزین سورس فعلی مخزن نکنید.**

## مواردی که در `src/index.js` باید اعمال شوند

سه تغییر زیر لازم است:

1. افزودن جست‌وجوی مخاطب با همان مسیری که اپ فعلی صدا می‌زند:
   `GET /api/v1/users/search?q=...`
2. اصلاح `POST /api/v1/conversations` تا شناسه اعضای انتخاب‌شده را واقعاً به گفتگو اضافه کند.
3. تکمیل `GET /api/v1/conversations` تا نام مخاطب، آخرین پیام، زمان آخرین پیام و آخرین بازدیدِ مجاز را به فهرست اپ برگرداند.

**هیچ‌کدام از مسیرهای ورود و ثبت‌نام تغییر نمی‌کنند.**  
هیچ Migration جدیدی لازم نیست؛ این تغییرات از جدول‌های فعلی استفاده می‌کنند.

## 1) جست‌وجوی مخاطب

این بلوک را بعد از احراز هویت کاربر (`const userId = session.sub;`) و پیش از مسیر `publicUserMatch` قرار دهید:

```js
if (path === "/api/v1/users/search" && req.method === "GET") {
  const query = (url.searchParams.get("q") || "").trim().slice(0, 64);
  if (!query) return json({ users: [] });
  const rows = await env.DB.prepare(
    "SELECT id,username,display_name FROM users WHERE username LIKE ? OR display_name LIKE ? OR id=? ORDER BY display_name LIMIT 30"
  ).bind(`%${query}%`, `%${query}%`, query).all();
  return json({ users: rows.results || [] });
}
```

## 2) جایگزینی کامل مسیر GET گفتگوها

بلوک فعلی `if (path === "/api/v1/conversations" && req.method === "GET")` را با این نسخه جایگزین کنید:

```js
if (path === "/api/v1/conversations" && req.method === "GET") {
  const rows = await env.DB.prepare(`
    SELECT c.id,c.type,
      CASE WHEN c.type='private' THEN COALESCE(
        (SELECT u.display_name FROM conversation_members peer
         JOIN users u ON u.id=peer.user_id
         WHERE peer.conversation_id=c.id AND peer.user_id<>? LIMIT 1),
        c.title
      ) ELSE c.title END AS title,
      c.created_at,
      (SELECT COUNT(*) FROM conversation_members m WHERE m.conversation_id=c.id) AS member_count,
      (SELECT COUNT(*) FROM messages unread
        WHERE unread.conversation_id=c.id AND unread.sender_id<>?
        AND unread.created_at>COALESCE(cm.last_read_at,'')
      ) AS unread_count,
      (SELECT lm.body FROM messages lm
        WHERE lm.conversation_id=c.id
        ORDER BY lm.created_at DESC LIMIT 1) AS last_message,
      (SELECT MAX(last_message.created_at) FROM messages last_message
        WHERE last_message.conversation_id=c.id) AS last_message_at,
      (SELECT CASE WHEN u.last_seen_privacy='everyone' THEN u.last_seen_at ELSE NULL END
       FROM conversation_members peer
       JOIN users u ON u.id=peer.user_id
       WHERE peer.conversation_id=c.id AND peer.user_id<>? LIMIT 1) AS peer_last_seen_at
    FROM conversations c
    JOIN conversation_members cm ON cm.conversation_id=c.id
    WHERE cm.user_id=?
    ORDER BY COALESCE(last_message_at,c.created_at) DESC
    LIMIT 100
  `).bind(userId, userId, userId, userId).all();
  return json({ items: rows.results || [] });
}
```

## 3) جایگزینی کامل مسیر POST گفتگوها

بلوک فعلی `if (path === "/api/v1/conversations" && req.method === "POST")` را با این نسخه جایگزین کنید:

```js
if (path === "/api/v1/conversations" && req.method === "POST") {
  const input = await body(req);
  const type = input.type === "group" ? "group" : "private";
  const title = String(input.title || "").trim().slice(0, 80);
  const memberIds = Array.isArray(input.member_ids)
    ? [...new Set(input.member_ids.map(value => String(value).trim()).filter(Boolean))]
    : [];

  if (type === "private" && memberIds.length !== 1) {
    return json({ error: "برای گفتگوی خصوصی دقیقاً یک مخاطب انتخاب کنید." }, 400);
  }
  if (type === "group" && (memberIds.length < 1 || memberIds.length > 50)) {
    return json({ error: "گروه باید بین ۱ تا ۵۰ عضو دیگر داشته باشد." }, 400);
  }
  if (memberIds.includes(userId)) {
    return json({ error: "شناسه خودتان را دوباره انتخاب نکنید." }, 400);
  }

  const found = await env.DB.prepare(
    `SELECT id FROM users WHERE id IN (${memberIds.map(() => "?").join(",")})`
  ).bind(...memberIds).all();

  if ((found.results || []).length !== memberIds.length) {
    return json({ error: "یک یا چند مخاطب پیدا نشدند." }, 404);
  }

  if (type === "private") {
    const existing = await env.DB.prepare(`
      SELECT c.id FROM conversations c
      JOIN conversation_members own
        ON own.conversation_id=c.id AND own.user_id=?
      JOIN conversation_members peer
        ON peer.conversation_id=c.id AND peer.user_id=?
      WHERE c.type='private' LIMIT 1
    `).bind(userId, memberIds[0]).first();

    if (existing) return json({ id: existing.id, type, title, existing: true });
  }

  const conversationId = uid();
  const at = now();
  const statements = [
    env.DB.prepare(
      "INSERT INTO conversations(id,type,title,created_by,created_at) VALUES(?,?,?,?,?)"
    ).bind(conversationId, type, title, userId, at),
    env.DB.prepare(
      "INSERT INTO conversation_members(conversation_id,user_id,member_role,joined_at) VALUES(?,?,?,?)"
    ).bind(conversationId, userId, "owner", at),
    ...memberIds.map(memberId => env.DB.prepare(
      "INSERT INTO conversation_members(conversation_id,user_id,member_role,joined_at) VALUES(?,?,?,?)"
    ).bind(conversationId, memberId, "member", at))
  ];

  await env.DB.batch(statements);
  return json({ id: conversationId, type, title, createdAt: at }, 201);
}
```


## 4) رسید خواندن برای گفتگوی گروهی

در هر دو کوئری GET پیام‌ها (شاخهٔ دارای `before` و شاخهٔ عادی)، عبارت فعلی:

```sql
EXISTS(SELECT 1 FROM message_reads mr
  WHERE mr.message_id=m.id AND mr.user_id<>m.sender_id) AS read_by_recipient
```

را با این عبارت جایگزین کنید. در گفتگوی خصوصی، رسید با خواندن مخاطب فعال می‌شود؛ در گروه، همهٔ اعضای دیگر باید پیام را خوانده باشند تا تیک آبی نمایش داده شود:

```sql
CASE
  WHEN (SELECT type FROM conversations WHERE id=m.conversation_id)='group'
  THEN (
    SELECT COUNT(DISTINCT mr.user_id)
    FROM message_reads mr
    WHERE mr.message_id=m.id AND mr.user_id<>m.sender_id
  ) >= (
    SELECT COUNT(*)-1 FROM conversation_members cm2
    WHERE cm2.conversation_id=m.conversation_id
  )
  ELSE EXISTS(
    SELECT 1 FROM message_reads mr
    WHERE mr.message_id=m.id AND mr.user_id<>m.sender_id
  )
END AS read_by_recipient
```

## نکتهٔ ایمنی و استقرار

- این اصلاحیه را فقط روی شاخه/Worker آزمایشی بررسی و آزمایش کنید.
- `wrangler.toml` فعلی مخزن به دیتابیس `vega-db` اشاره می‌کند؛ پیش از هر Deploy باید مطمئن شوید تنظیمات Worker آزمایشی به `vega-db-test` متصل است.
- این بسته هیچ دستور Deploy یا Migration خودکاری اجرا نمی‌کند.
- مسیرهای `/api/v1/register` و `/api/v1/login` عمداً دست‌نخورده می‌مانند.
