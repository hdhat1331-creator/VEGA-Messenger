import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

const apiBaseUrl = 'https://vega-server.v58073149.workers.dev';
const bg = Color(0xFF090D1C), panel = Color(0xFF151B32), purple = Color(0xFF8B5CF6), cyan = Color(0xFF35D5D0);

void main() => runApp(const VegaApp());

class Api {
  static String? token;
  static Future<Map<String,dynamic>> request(String path,{String method='GET',Map<String,dynamic>? data}) async {
    final headers={'content-type':'application/json',if(token!=null)'authorization':'Bearer $token'};
    final uri=Uri.parse('$apiBaseUrl$path');
    final res= method=='POST'
      ? await http.post(uri,headers:headers,body:jsonEncode(data??{})).timeout(const Duration(seconds:15))
      : await http.get(uri,headers:headers).timeout(const Duration(seconds:15));
    final decoded=jsonDecode(res.body) as Map<String,dynamic>;
    if(res.statusCode>=400) throw Exception(decoded['error']??'خطای ارتباط با سرور');
    return decoded;
  }
}

class VegaApp extends StatelessWidget {
  const VegaApp({super.key});
  @override Widget build(BuildContext context)=>MaterialApp(
    title:'VEGA',debugShowCheckedModeBanner:false,
    theme:ThemeData.dark().copyWith(scaffoldBackgroundColor:bg,
      colorScheme:const ColorScheme.dark(primary:purple,secondary:cyan),
      inputDecorationTheme:InputDecorationTheme(filled:true,fillColor:panel,
        border:OutlineInputBorder(borderRadius:BorderRadius.circular(14),borderSide:BorderSide.none))),
    home:const Gate());
}
class Gate extends StatefulWidget { const Gate({super.key}); @override State<Gate> createState()=>_GateState(); }
class _GateState extends State<Gate>{
 @override void initState(){super.initState();_load();}
 Future<void> _load() async {final p=await SharedPreferences.getInstance();Api.token=p.getString('token');if(mounted)setState((){});}
 @override Widget build(BuildContext c)=>Api.token==null?const AuthPage():const HomePage();
}
class AuthPage extends StatefulWidget {const AuthPage({super.key});@override State<AuthPage> createState()=>_AuthPageState();}
class _AuthPageState extends State<AuthPage>{
 final user=TextEditingController(),name=TextEditingController(),pass=TextEditingController();
 bool register=false,busy=false;String? error;
 Future<void> submit() async {setState(()=>{busy=true,error=null});try{
  final r=await Api.request(register?'/api/v1/register':'/api/v1/login',method:'POST',
   data:{'username':user.text,'displayName':name.text,'password':pass.text});
  Api.token=r['token'];final p=await SharedPreferences.getInstance();await p.setString('token',Api.token!);
  if(mounted)Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>const HomePage()));
 }catch(e){setState(()=>error=e.toString());}finally{if(mounted)setState(()=>busy=false);}}
 @override Widget build(BuildContext c)=>Scaffold(body:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(24),child:Column(
  mainAxisAlignment:MainAxisAlignment.center,children:[
   const Icon(Icons.change_circle_rounded,size:76,color:cyan),const SizedBox(height:8),
   const Text('VEGA',style:TextStyle(fontSize:34,fontWeight:FontWeight.w800,letterSpacing:5)),
   const SizedBox(height:28),Text(register?'ساخت حساب':'ورود به حساب',style:const TextStyle(fontSize:22)),
   const SizedBox(height:18),TextField(controller:user,decoration:const InputDecoration(labelText:'نام کاربری')),
   if(register)...[const SizedBox(height:12),TextField(controller:name,decoration:const InputDecoration(labelText:'نام نمایشی'))],
   const SizedBox(height:12),TextField(controller:pass,obscureText:true,decoration:const InputDecoration(labelText:'گذرواژه')),
   if(error!=null)Padding(padding:const EdgeInsets.all(10),child:Text(error!,style:const TextStyle(color:Colors.redAccent))),
   const SizedBox(height:18),SizedBox(width:double.infinity,child:FilledButton(onPressed:busy?null:submit,
    child:Text(busy?'لطفاً صبر کنید':register?'ثبت‌نام':'ورود'))),
   TextButton(onPressed:()=>setState(()=>register=!register),child:Text(register?'حساب دارم':'ایجاد حساب جدید'))
 ]))));
}
class HomePage extends StatefulWidget {const HomePage({super.key});@override State<HomePage> createState()=>_HomePageState();}
class _HomePageState extends State<HomePage>{
 List items=[];String? error;
 @override void initState(){super.initState();load();}
 Future<void> load() async {try{final r=await Api.request('/api/v1/conversations');setState(()=>items=r['items']??[]);}catch(e){setState(()=>error=e.toString());}}
 Future<void> create() async {final c=TextEditingController();final ok=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(
  title:const Text('گفتگوی جدید'),content:TextField(controller:c,decoration:const InputDecoration(labelText:'عنوان')),
  actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('لغو')),
  FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('ایجاد'))]));
  if(ok==true){try{await Api.request('/api/v1/conversations',method:'POST',data:{'type':'group','title':c.text});await load();}catch(e){setState(()=>error=e.toString());}}
 }
 Future<void> logout() async {final p=await SharedPreferences.getInstance();await p.remove('token');Api.token=null;if(mounted)Navigator.pushAndRemoveUntil(context,MaterialPageRoute(builder:(_)=>const AuthPage()),(_)=>false);}
 @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('VEGA'),actions:[
  IconButton(onPressed:load,icon:const Icon(Icons.refresh)),IconButton(onPressed:logout,icon:const Icon(Icons.logout))]),
  floatingActionButton:FloatingActionButton(onPressed:create,child:const Icon(Icons.add)),
  body:error!=null?Center(child:Text(error!)):items.isEmpty?const Center(child:Text('هنوز گفتگویی ندارید')):ListView.builder(
   itemCount:items.length,itemBuilder:(c,i){final x=items[i];return ListTile(leading:const CircleAvatar(backgroundColor:panel,child:Icon(Icons.forum,color:cyan)),
    title:Text(x['title']?.toString().isNotEmpty==true?x['title']:'گفتگو'),subtitle:Text(x['type']??''),
    onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>ChatPage(id:x['id']))));}));
}
class ChatPage extends StatefulWidget {final String id;const ChatPage({super.key,required this.id});@override State<ChatPage> createState()=>_ChatPageState();}
class _ChatPageState extends State<ChatPage>{
 final input=TextEditingController();List messages=[];String? error;
 @override void initState(){super.initState();load();}
 Future<void> load() async {try{final r=await Api.request('/api/v1/conversations/${widget.id}/messages');setState(()=>messages=r['items']??[]);}catch(e){setState(()=>error=e.toString());}}
 Future<void> send() async {final value=input.text.trim();if(value.isEmpty)return;input.clear();try{await Api.request('/api/v1/conversations/${widget.id}/messages',method:'POST',data:{'body':value});await load();}catch(e){setState(()=>error=e.toString());}}
 @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('گفتگو'),actions:[IconButton(onPressed:load,icon:const Icon(Icons.refresh))]),
 body:Column(children:[if(error!=null)Text(error!,style:const TextStyle(color:Colors.redAccent)),
 Expanded(child:ListView(children:messages.map<Widget>((m)=>Align(alignment:Alignment.centerRight,child:Container(
 margin:const EdgeInsets.all(7),padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:panel,borderRadius:BorderRadius.circular(14)),
 child:Text(m['body']??'')))).toList())),
 SafeArea(child:Padding(padding:const EdgeInsets.all(10),child:Row(children:[Expanded(child:TextField(controller:input,decoration:const InputDecoration(hintText:'پیام...'))),
 IconButton(onPressed:send,icon:const Icon(Icons.send,color:cyan))]))) ]));
}
