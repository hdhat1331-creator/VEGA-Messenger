# VEGA Phase 8 — UI and message refresh update

This package keeps the existing backend files and API base URL unchanged.

## App changes
- Own messages align right with purple bubbles.
- Other participants' messages align left with a dark contrasting bubble.
- The app reads the signed-in user ID from the JWT payload only for local message alignment; the server remains responsible for token verification.
- The chat screen polls for new messages every 4 seconds while the chat screen is active, and stops polling when the app is backgrounded.
- The supplied VEGA V icon is used for the Android launcher icon.
- The supplied VEGA wordmark and arrow are used on the sign-in/register screen and the home app bar.

## Build
The GitHub Actions workflow creates the Android project scaffold if missing, generates launcher icons, and builds the release APK.

No server code or database migrations were changed in this update.
