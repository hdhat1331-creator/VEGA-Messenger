import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

const apiBaseUrl = 'https://vega-server.v58073149.workers.dev';
const bg = Color(0xFF090D1C);
const panel = Color(0xFF151B32);
const purple = Color(0xFF8B5CF6);
const cyan = Color(0xFF35D5D0);

void main() => runApp(const VegaApp());

class Api {
  static String? token;

  // Used only to decide which side of the chat a message belongs on.
  // The server still validates the signed token for every API request.
  static String? get currentUserId {
    try {
      final parts = token?.split('.');
      if (parts == null || parts.length != 3) return null;
      final payload = jsonDecode(
        utf8.decode(base64Url.decode(base64Url.normalize(parts[1]))),
      ) as Map<String, dynamic>;
      return payload['sub']?.toString();
    } catch (_) {
      return null;
    }
  }

  static Future<Map<String, dynamic>> request(
    String path, {
    String method = 'GET',
    Map<String, dynamic>? data,
  }) async {
    final headers = {
      'content-type': 'application/json',
      if (token != null) 'authorization': 'Bearer $token',
    };
    final uri = Uri.parse('$apiBaseUrl$path');
    final res = method == 'POST'
        ? await http
            .post(uri, headers: headers, body: jsonEncode(data ?? {}))
            .timeout(const Duration(seconds: 15))
        : await http.get(uri, headers: headers).timeout(
              const Duration(seconds: 15),
            );
    final decoded = jsonDecode(res.body) as Map<String, dynamic>;
    if (res.statusCode >= 400) {
      throw Exception(decoded['error'] ?? 'خطای ارتباط با سرور');
    }
    return decoded;
  }
}

class VegaApp extends StatelessWidget {
  const VegaApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'VEGA',
        debugShowCheckedModeBanner: false,
        theme: ThemeData.dark().copyWith(
          scaffoldBackgroundColor: bg,
          colorScheme: const ColorScheme.dark(
            primary: purple,
            secondary: cyan,
          ),
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: panel,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide.none,
            ),
          ),
        ),
        home: const Gate(),
      );
}

class Gate extends StatefulWidget {
  const Gate({super.key});
  @override
  State<Gate> createState() => _GateState();
}

class _GateState extends State<Gate> {
  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    Api.token = p.getString('token');
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext c) =>
      Api.token == null ? const AuthPage() : const HomePage();
}

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});
  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  final user = TextEditingController();
  final name = TextEditingController();
  final pass = TextEditingController();
  bool register = false;
  bool busy = false;
  String? error;

  Future<void> submit() async {
    setState(() {
      busy = true;
      error = null;
    });
    try {
      final r = await Api.request(
        register ? '/api/v1/register' : '/api/v1/login',
        method: 'POST',
        data: {
          'username': user.text,
          'displayName': name.text,
          'password': pass.text,
        },
      );
      Api.token = r['token'];
      final p = await SharedPreferences.getInstance();
      await p.setString('token', Api.token!);
      if (mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const HomePage()),
        );
      }
    } catch (e) {
      if (mounted) setState(() => error = e.toString());
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  void dispose() {
    user.dispose();
    name.dispose();
    pass.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext c) => Scaffold(
        body: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset(
                  'assets/vega_wordmark.png',
                  width: 270,
                  height: 150,
                  fit: BoxFit.contain,
                ),
                const SizedBox(height: 20),
                Text(
                  register ? 'ساخت حساب' : 'ورود به حساب',
                  style: const TextStyle(fontSize: 22),
                ),
                const SizedBox(height: 18),
                TextField(
                  controller: user,
                  decoration: const InputDecoration(labelText: 'نام کاربری'),
                ),
                if (register) ...[
                  const SizedBox(height: 12),
                  TextField(
                    controller: name,
                    decoration:
                        const InputDecoration(labelText: 'نام نمایشی'),
                  ),
                ],
                const SizedBox(height: 12),
                TextField(
                  controller: pass,
                  obscureText: true,
                  decoration: const InputDecoration(labelText: 'گذرواژه'),
                ),
                if (error != null)
                  Padding(
                    padding: const EdgeInsets.all(10),
                    child: Text(
                      error!,
                      style: const TextStyle(color: Colors.redAccent),
                    ),
                  ),
                const SizedBox(height: 18),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: busy ? null : submit,
                    child: Text(
                      busy
                          ? 'لطفاً صبر کنید'
                          : register
                              ? 'ثبت‌نام'
                              : 'ورود',
                    ),
                  ),
                ),
                TextButton(
                  onPressed: () => setState(() => register = !register),
                  child: Text(register ? 'حساب دارم' : 'ایجاد حساب جدید'),
                ),
              ],
            ),
          ),
        ),
      );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List items = [];
  String? error;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final r = await Api.request('/api/v1/conversations');
      if (mounted) setState(() => items = r['items'] ?? []);
    } catch (e) {
      if (mounted) setState(() => error = e.toString());
    }
  }

  Future<void> create() async {
    final c = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('گفتگوی جدید'),
        content: TextField(
          controller: c,
          decoration: const InputDecoration(labelText: 'عنوان'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('لغو'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('ایجاد'),
          ),
        ],
      ),
    );
    if (ok == true) {
      try {
        await Api.request(
          '/api/v1/conversations',
          method: 'POST',
          data: {'type': 'group', 'title': c.text},
        );
        await load();
      } catch (e) {
        if (mounted) setState(() => error = e.toString());
      }
    }
    c.dispose();
  }

  Future<void> logout() async {
    final p = await SharedPreferences.getInstance();
    await p.remove('token');
    Api.token = null;
    if (mounted) {
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (_) => const AuthPage()),
        (_) => false,
      );
    }
  }

  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(
          title: Image.asset(
            'assets/vega_wordmark.png',
            width: 112,
            height: 42,
            fit: BoxFit.contain,
          ),
          actions: [
            IconButton(onPressed: load, icon: const Icon(Icons.refresh)),
            IconButton(onPressed: logout, icon: const Icon(Icons.logout)),
          ],
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: create,
          child: const Icon(Icons.add),
        ),
        body: error != null
            ? Center(child: Text(error!))
            : items.isEmpty
                ? const Center(child: Text('هنوز گفتگویی ندارید'))
                : ListView.builder(
                    itemCount: items.length,
                    itemBuilder: (c, i) {
                      final x = items[i];
                      return ListTile(
                        leading: const CircleAvatar(
                          backgroundColor: panel,
                          child: Icon(Icons.forum, color: cyan),
                        ),
                        title: Text(
                          x['title']?.toString().isNotEmpty == true
                              ? x['title']
                              : 'گفتگو',
                        ),
                        subtitle: Text(x['type'] ?? ''),
                        onTap: () => Navigator.push(
                          c,
                          MaterialPageRoute(
                            builder: (_) => ChatPage(id: x['id']),
                          ),
                        ),
                      );
                    },
                  ),
      );
}

class ChatPage extends StatefulWidget {
  final String id;
  const ChatPage({super.key, required this.id});

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> with WidgetsBindingObserver {
  final input = TextEditingController();
  final scroll = ScrollController();
  final List messages = [];
  String? error;
  Timer? _pollTimer;
  bool _loading = false;
  bool _sending = false;
  bool _active = true;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    load();
    _startPolling();
  }

  void _startPolling() {
    _pollTimer?.cancel();
    if (!_active) return;
    // Poll only while this chat screen is visible; no background polling.
    _pollTimer = Timer.periodic(
      const Duration(seconds: 4),
      (_) => load(silent: true),
    );
  }

  void _stopPolling() {
    _pollTimer?.cancel();
    _pollTimer = null;
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _active = true;
      load(silent: true);
      _startPolling();
    } else {
      _active = false;
      _stopPolling();
    }
  }

  Future<void> load({bool silent = false}) async {
    if (_loading || !_active) return;
    _loading = true;
    try {
      final r = await Api.request(
        '/api/v1/conversations/${widget.id}/messages',
      );
      if (!mounted) return;
      final incoming = (r['items'] as List? ?? []);
      final changed = incoming.length != messages.length ||
          (incoming.isNotEmpty &&
              messages.isNotEmpty &&
              incoming.last['id'] != messages.last['id']);
      if (changed) {
        setState(() {
          messages
            ..clear()
            ..addAll(incoming);
          error = null;
        });
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted && scroll.hasClients) {
            scroll.animateTo(
              scroll.position.maxScrollExtent,
              duration: const Duration(milliseconds: 220),
              curve: Curves.easeOut,
            );
          }
        });
      } else if (!silent && error != null) {
        setState(() => error = null);
      }
    } catch (e) {
      if (mounted && !silent) setState(() => error = e.toString());
    } finally {
      _loading = false;
    }
  }

  Future<void> send() async {
    final value = input.text.trim();
    if (value.isEmpty || _sending) return;
    setState(() => _sending = true);
    input.clear();
    try {
      await Api.request(
        '/api/v1/conversations/${widget.id}/messages',
        method: 'POST',
        data: {'body': value},
      );
      await load();
    } catch (e) {
      if (mounted) {
        input.text = value;
        setState(() => error = e.toString());
      }
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Widget _messageBubble(Map<String, dynamic> message, bool mine) {
    final bubbleColor = mine ? purple : const Color(0xFF202A43);
    return Align(
      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 310),
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            color: bubbleColor,
            borderRadius: BorderRadius.only(
              topLeft: const Radius.circular(16),
              topRight: const Radius.circular(16),
              bottomLeft: Radius.circular(mine ? 16 : 4),
              bottomRight: Radius.circular(mine ? 4 : 16),
            ),
            border: mine
                ? null
                : Border.all(color: cyan.withOpacity(0.18), width: 1),
          ),
          child: Text(
            message['body']?.toString() ?? '',
            style: const TextStyle(fontSize: 15, color: Colors.white),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _stopPolling();
    WidgetsBinding.instance.removeObserver(this);
    input.dispose();
    scroll.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext c) {
    final myId = Api.currentUserId;
    return Scaffold(
      appBar: AppBar(
        title: const Text('گفتگو'),
        actions: [
          IconButton(
            onPressed: () => load(),
            icon: const Icon(Icons.refresh),
            tooltip: 'بروزرسانی دستی',
          ),
        ],
      ),
      body: Column(
        children: [
          if (error != null)
            Padding(
              padding: const EdgeInsets.all(8),
              child: Text(
                error!,
                style: const TextStyle(color: Colors.redAccent),
              ),
            ),
          Expanded(
            child: ListView.builder(
              controller: scroll,
              padding: const EdgeInsets.symmetric(vertical: 8),
              itemCount: messages.length,
              itemBuilder: (context, index) {
                final m = Map<String, dynamic>.from(messages[index] as Map);
                final mine = myId != null &&
                    m['sender_id']?.toString() == myId;
                return _messageBubble(m, mine);
              },
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: input,
                      minLines: 1,
                      maxLines: 4,
                      textInputAction: TextInputAction.send,
                      onSubmitted: (_) => send(),
                      decoration:
                          const InputDecoration(hintText: 'پیام...'),
                    ),
                  ),
                  IconButton(
                    onPressed: _sending ? null : send,
                    icon: const Icon(Icons.send, color: cyan),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
