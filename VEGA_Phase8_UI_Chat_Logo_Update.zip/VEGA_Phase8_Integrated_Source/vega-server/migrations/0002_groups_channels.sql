PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS groups (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  owner_user_id TEXT NOT NULL,
  invite_code TEXT UNIQUE,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS group_members (
  group_id TEXT NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'member' CHECK(role IN ('owner','admin','member')),
  joined_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  muted INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY(group_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_group_members_user ON group_members(user_id);

CREATE TABLE IF NOT EXISTS channels (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  owner_user_id TEXT NOT NULL,
  visibility TEXT NOT NULL DEFAULT 'private' CHECK(visibility IN ('public','private')),
  invite_code TEXT UNIQUE,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS channel_subscribers (
  channel_id TEXT NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'subscriber' CHECK(role IN ('owner','admin','subscriber')),
  joined_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  muted INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY(channel_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_channel_subscribers_user ON channel_subscribers(user_id);

CREATE TABLE IF NOT EXISTS channel_posts (
  id TEXT PRIMARY KEY,
  channel_id TEXT NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  author_user_id TEXT NOT NULL,
  body TEXT NOT NULL DEFAULT '',
  media_descriptor TEXT,
  views_count INTEGER NOT NULL DEFAULT 0,
  pinned INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_channel_posts_channel_date ON channel_posts(channel_id, created_at DESC);

CREATE TABLE IF NOT EXISTS channel_post_reactions (
  post_id TEXT NOT NULL REFERENCES channel_posts(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL,
  reaction TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY(post_id, user_id, reaction)
);

CREATE TABLE IF NOT EXISTS community_invites (
  code TEXT PRIMARY KEY,
  target_type TEXT NOT NULL CHECK(target_type IN ('group','channel')),
  target_id TEXT NOT NULL,
  created_by TEXT NOT NULL,
  expires_at TEXT,
  max_uses INTEGER,
  uses INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS community_polls (
  id TEXT PRIMARY KEY,
  target_type TEXT NOT NULL CHECK(target_type IN ('group','channel')),
  target_id TEXT NOT NULL,
  creator_user_id TEXT NOT NULL,
  question TEXT NOT NULL,
  multiple_choice INTEGER NOT NULL DEFAULT 0,
  closes_at TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS community_poll_options (
  id TEXT PRIMARY KEY,
  poll_id TEXT NOT NULL REFERENCES community_polls(id) ON DELETE CASCADE,
  option_text TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS community_poll_votes (
  poll_id TEXT NOT NULL REFERENCES community_polls(id) ON DELETE CASCADE,
  option_id TEXT NOT NULL REFERENCES community_poll_options(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY(poll_id, option_id, user_id)
);
