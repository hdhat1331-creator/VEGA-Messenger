PRAGMA foreign_keys = ON;

-- The server stores only encrypted message envelopes for offline delivery.
CREATE TABLE IF NOT EXISTS offline_message_queue (
  id TEXT PRIMARY KEY,
  conversation_id TEXT NOT NULL,
  sender_user_id TEXT NOT NULL,
  recipient_user_id TEXT NOT NULL,
  encrypted_payload TEXT NOT NULL,
  idempotency_key TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  UNIQUE(sender_user_id, idempotency_key)
);
CREATE INDEX IF NOT EXISTS idx_offline_queue_recipient
  ON offline_message_queue(recipient_user_id, created_at, id);

-- Per-user change feed. payload_json must contain metadata or encrypted data only.
CREATE TABLE IF NOT EXISTS sync_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  event_type TEXT NOT NULL,
  payload_json TEXT NOT NULL DEFAULT '{}',
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sync_events_user_cursor
  ON sync_events(user_id, id);

CREATE TABLE IF NOT EXISTS notification_preferences (
  user_id TEXT PRIMARY KEY,
  direct_messages INTEGER NOT NULL DEFAULT 1,
  group_messages INTEGER NOT NULL DEFAULT 1,
  channel_posts INTEGER NOT NULL DEFAULT 1,
  sound_enabled INTEGER NOT NULL DEFAULT 1,
  updated_at INTEGER NOT NULL
);

-- FCM/APNs token registry only; actual push delivery needs provider credentials.
CREATE TABLE IF NOT EXISTS push_devices (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  platform TEXT NOT NULL,
  push_token TEXT NOT NULL,
  device_label TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  UNIQUE(user_id, push_token)
);
CREATE INDEX IF NOT EXISTS idx_push_devices_user ON push_devices(user_id);
